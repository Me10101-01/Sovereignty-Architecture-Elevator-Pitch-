# Deployment Guide: StrategicKhaos AI Board

**Version**: 1.0  
**Date**: November 30, 2025

---

## Overview

This guide covers deploying the StrategicKhaos AI Board infrastructure on your Starlink/Verizon mesh. The system consists of:

- **5 AI Board Agents**: gpt_duck, claude_prime, claude_parallel, grok_guardian, gemini_ideator
- **5 Infrastructure Services**: NATS, OPA, audit_trail, monitor_comms, finance_enforcer
- **3 Supporting Services**: Qdrant, Redis, Ollama
- **2 Idea Services**: svc-contextual-memory (IDEA_001), svc-code-diagram (IDEA_026)

---

## Prerequisites

### Required
- Docker & Docker Compose
- Git (for audit trail anchoring)
- 16GB+ RAM (for Ollama + embeddings)

### Optional
- NVIDIA GPU (for faster Ollama inference)
- Google Cloud service account (for Gmail/Drive monitoring)
- Stripe API key (for finance enforcement)
- API keys: OpenAI, Anthropic, xAI, Google

---

## Quick Start

### 1. Clone and Setup

```bash
git clone https://github.com/strategickhaos-swarm-intelligence/strategickhaos.git
cd strategickhaos

# Create secrets directory
mkdir -p secrets
# Add your Google service account JSON if using comms monitoring
# touch secrets/credentials.json
```

### 2. Create Environment File

```bash
cat > .env << 'EOF'
# API Keys (optional - agents work without these)
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
XAI_API_KEY=xai-...
GOOGLE_API_KEY=AIza...
STRIPE_SECRET_KEY=sk_test_...

# Board Gates (set to true after human approval)
PIA_APPROVED=false
ZK_ENCRYPTION_CONFIRMED=false
EOF
```

### 3. Start Infrastructure Only

```bash
docker compose up -d nats opa qdrant redis ollama
```

Verify:
```bash
curl http://localhost:8222/healthz  # NATS
curl http://localhost:8181/health   # OPA
curl http://localhost:6333          # Qdrant
redis-cli ping                       # Redis
curl http://localhost:11434/api/tags # Ollama
```

### 4. Start AI Board Agents

```bash
docker compose up -d gpt_duck claude_prime claude_parallel grok_guardian gemini_ideator
docker compose up -d audit_trail finance_enforcer
```

### 5. Start Idea Services

**IDEA_026 (Code-to-Diagram)** — No gates required:
```bash
docker compose up -d svc-code-diagram
curl http://localhost:8002/health
```

**IDEA_001 (Contextual Memory)** — Gates required:

⚠️ DO NOT deploy until after human approval of:
- Privacy Impact Assessment (PIA)
- Zero-Knowledge Encryption confirmation

After approval:
```bash
export PIA_APPROVED=true
export ZK_ENCRYPTION_CONFIRMED=true
docker compose up -d svc-contextual-memory
curl http://localhost:8001/health
```

---

## Board Deliberation

### Trigger via NATS

```bash
# Install NATS CLI
go install github.com/nats-io/natscli/nats@latest

# Trigger deliberation
nats pub board.deliberate '{"idea_id": "IDEA_001", "action": "birth"}'

# Watch decisions
nats sub "board.decisions"
```

### Trigger via API

```bash
curl -X POST http://localhost:8000/deliberate \
  -H "Content-Type: application/json" \
  -d '{"idea_id": "IDEA_001", "action": "review"}'
```

---

## OPA Policy Testing

```bash
# Test approval
curl -X POST http://localhost:8181/v1/data/guardrails/approve \
  -d '{"input": {"role": "pattern_analyst", "recommendation": "Deploy infra"}}'

# Test denial (unsafe keyword)
curl -X POST http://localhost:8181/v1/data/guardrails/approve \
  -d '{"input": {"role": "pattern_analyst", "recommendation": "Hack the system"}}'
```

---

## Mesh Integration

### WireGuard Setup

Expose NATS on your WireGuard mesh for cross-node communication:

```ini
# /etc/wireguard/wg0.conf (add to existing)
[Peer]
# Sky Command Center
PublicKey = <your-key>
AllowedIPs = 10.0.0.1/32
Endpoint = <starlink-ip>:51820

# Forward NATS
PostUp = iptables -A FORWARD -i wg0 -p tcp --dport 4222 -j ACCEPT
```

### Port Mapping

| Service | Port | Expose on Mesh? |
|---------|------|-----------------|
| NATS | 4222 | Yes (authenticated) |
| OPA | 8181 | No (internal only) |
| Qdrant | 6333 | No (internal only) |
| Redis | 6379 | No (internal only) |
| Ollama | 11434 | No (internal only) |
| Ideas | 8001-8002 | Via Ingress |

---

## Monitoring

### View Logs

```bash
docker compose logs -f gpt_duck
docker compose logs -f audit_trail
```

### Check Board Status

```bash
# All agents
for agent in gpt_duck claude_prime grok_guardian gemini_ideator; do
  echo "$agent: $(curl -s http://localhost:8000/health 2>/dev/null || echo 'down')"
done
```

### Query Audit Trail

```bash
# View Merkle roots
cat audit/merkle_roots.txt

# Query SQLite (if sqlite-vec installed)
sqlite3 audit_logs/audit.db "SELECT * FROM logs ORDER BY rowid DESC LIMIT 10"
```

---

## Scaling to Kubernetes

See `k8s/` directories in each repo for production manifests:

```bash
# Deploy namespace
kubectl apply -f repos/contextual-memory-assistant/k8s/deployment.yaml

# Check gates
kubectl get configmap contextual-memory-gates -n ns-education -o yaml
```

---

## Troubleshooting

### NATS not connecting
```bash
docker compose logs nats
# Check if JetStream is enabled
nats server info
```

### OPA denying everything
```bash
# Check policy syntax
opa check opa/policies/guardrails.rego

# Test with trace
curl -X POST "http://localhost:8181/v1/data/guardrails/approve?explain=full" \
  -d '{"input": {"role": "pattern_analyst", "recommendation": "test"}}'
```

### IDEA_001 blocked by gates
```bash
# Check gate status
curl http://localhost:8001/health

# Must set env vars BEFORE starting container
docker compose down svc-contextual-memory
PIA_APPROVED=true ZK_ENCRYPTION_CONFIRMED=true docker compose up -d svc-contextual-memory
```

---

## Security Checklist

- [ ] API keys in `.env` (not committed)
- [ ] OPA policies reviewed
- [ ] NATS authentication enabled (production)
- [ ] WireGuard mesh secured
- [ ] Board resolution signed
- [ ] PIA completed (for IDEA_001)
- [ ] Encryption confirmed (for IDEA_001)

---

## Next Steps

1. **Clear IDEA_001 gates** — Complete PIA and encryption review
2. **Deploy to mesh** — Distribute across Starlink/Verizon nodes
3. **Birth more ideas** — Use `nats pub board.deliberate` workflow
4. **Scale to K8s** — Apply production manifests

---

*The board is seated. The swarm awaits your command, Sky Commander.*

---

*StrategicKhaos DAO LLC — Wyoming Entity ID: 2025-001708194*
