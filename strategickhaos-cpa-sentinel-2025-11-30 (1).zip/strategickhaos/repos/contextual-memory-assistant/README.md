# Contextual Memory Assistant

> **IDEA_001** | Category: `ai-enhanced-personalization` | Priority: `critical`  
> **Bloom's Level**: 6-Create | **Video Module**: Q001  
> **Namespace**: `ns-education` | **Service**: `svc-contextual-memory`

## Board Deliberation Status

**Status**: ✅ CONDITIONALLY APPROVED  
**Date**: November 30, 2025  
**Resolution**: Board Deliberation #001

### Mandatory Gates (Human Approval Required)

| Gate | Requirement | Status | Owner |
|------|-------------|--------|-------|
| 🔒 **Legal** | Privacy Impact Assessment (PIA) | ⏳ PENDING | Dom |
| 🔐 **Architecture** | Zero-Knowledge Encryption Confirmation | ⏳ PENDING | Dom |

> **⚠️ WARNING**: This service CANNOT be deployed to production until both gates are cleared.
> The OPA policy `guardrails.rego` enforces this at runtime.

---

## Overview

An AI-powered assistant that builds a knowledge graph of user interactions and surfaces context-aware prompts and memory support during future tasks. Uses NLP to track relationships, commitments, and facts from conversations (with explicit user consent).

**Alignment**: Swarm Memory Mesh integration. High-priority for Q1 2026 MVP.

---

## Privacy-First Architecture

Due to the sensitive nature of this service, the architecture is designed with privacy as a core principle:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         USER DEVICE (Local Processing)                       │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────────────────┐  │
│  │   Consent   │───▶│  Whisper    │───▶│  Local Embedding Generator     │  │
│  │   Manager   │    │  (Local)    │    │  (sentence-transformers)       │  │
│  └─────────────┘    └─────────────┘    └────────────────┬────────────────┘  │
│                                                          │                   │
│                                        ┌─────────────────▼────────────────┐  │
│                                        │  Zero-Knowledge Encryption       │  │
│                                        │  (NaCl/libsodium)                │  │
│                                        └─────────────────┬────────────────┘  │
└──────────────────────────────────────────────────────────┼──────────────────┘
                                                           │
                                          Encrypted Vectors Only
                                                           │
                                                           ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              SERVER (Blind Storage)                          │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────────────┐  │
│  │  Qdrant Vector  │    │  Redis Session  │    │  Audit Trail            │  │
│  │  Store (Blind)  │    │  Cache          │    │  (Merkle + Git)         │  │
│  └─────────────────┘    └─────────────────┘    └─────────────────────────┘  │
│                                                                              │
│  Server CANNOT decrypt user data. Only stores encrypted vectors.             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Features

- **Consent-First**: No recording without explicit, granular user consent
- **Zero-Knowledge Storage**: Server stores encrypted vectors only; cannot decrypt
- **Local Processing**: Audio transcription and embedding happen on-device
- **Knowledge Graph**: Tracks relationships, commitments, facts
- **Context-Aware Prompts**: Surfaces relevant memories during tasks
- **GDPR/CCPA Compliant**: Built-in data export and deletion

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run in local-only mode (no server connection)
python main.py local --consent-file consent.json

# Run API server (for development)
python main.py serve --port 8000

# Query memories
python main.py query "What did I discuss with Sarah about the project?"
```

---

## Consent Management

Users must explicitly consent before any data processing:

```python
from contextual_memory import ConsentManager

consent = ConsentManager()

# Check consent status
if not consent.has_consent("audio_recording"):
    consent.request_consent(
        scope="audio_recording",
        description="Record conversations to build your personal knowledge graph",
        retention_days=365,
        deletion_callback=delete_user_data
    )
```

Consent is stored locally and can be revoked at any time:

```bash
python main.py consent --revoke audio_recording
python main.py consent --export  # GDPR data export
python main.py consent --delete-all  # Right to be forgotten
```

---

## API Endpoints

| Endpoint | Method | Description | Requires Consent |
|----------|--------|-------------|------------------|
| `/health` | GET | Health check | No |
| `/consent` | GET/POST | Manage consent | No |
| `/ingest` | POST | Ingest encrypted memory | Yes |
| `/query` | POST | Query knowledge graph | Yes |
| `/export` | GET | Export all user data | Yes |
| `/delete` | DELETE | Delete all user data | Yes |

---

## Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `QDRANT_URL` | `http://localhost:6333` | Vector store URL |
| `REDIS_URL` | `redis://localhost:6379` | Session cache URL |
| `ENCRYPTION_KEY` | *Required* | User's encryption key (never sent to server) |
| `CONSENT_FILE` | `~/.contextual-memory/consent.json` | Local consent storage |
| `LOCAL_ONLY` | `false` | Disable server sync entirely |

---

## Zero-Knowledge Encryption

All user data is encrypted client-side before transmission:

```python
from nacl.secret import SecretBox
from nacl.utils import random

# User's key (derived from password, stored locally)
key = derive_key_from_password(user_password)
box = SecretBox(key)

# Encrypt locally before sending to server
encrypted = box.encrypt(embedding_bytes)

# Server stores encrypted blob; cannot decrypt
server.store(user_id, encrypted)
```

The server performs vector similarity search on encrypted embeddings using homomorphic-compatible techniques (planned for v2).

---

## Privacy Impact Assessment (PIA) Checklist

> **Gate Status**: ⏳ PENDING HUMAN APPROVAL

- [ ] Data minimization: Only collect what's necessary
- [ ] Purpose limitation: Data used only for stated purpose
- [ ] Storage limitation: Automatic deletion after retention period
- [ ] User rights: Export, deletion, correction implemented
- [ ] Security measures: Encryption at rest and in transit
- [ ] Third-party sharing: None (zero-knowledge architecture)
- [ ] Breach notification: Automated alerts configured
- [ ] Consent mechanism: Granular, revocable consent implemented

**PIA Approved By**: ________________________ (Operator Signature)  
**Date**: ________________________

---

## Zero-Knowledge Encryption Confirmation

> **Gate Status**: ⏳ PENDING HUMAN APPROVAL

- [ ] Client-side encryption implemented (NaCl/libsodium)
- [ ] Server cannot decrypt user data
- [ ] Encryption keys never leave user device
- [ ] Key derivation uses secure KDF (Argon2id)
- [ ] No plaintext logging on server
- [ ] Audit trail encrypted with separate keys

**Encryption Confirmed By**: ________________________ (Operator Signature)  
**Date**: ________________________

---

## Dependencies

- `sentence-transformers` — Local embedding generation
- `qdrant-client` — Vector database client
- `redis` — Session caching
- `pynacl` — Zero-knowledge encryption (NaCl bindings)
- `faster-whisper` — Local audio transcription
- `fastapi` — API framework
- `typer` — CLI framework

---

## Kubernetes Deployment

```bash
# Only after both gates are cleared!
kubectl apply -f k8s/deployment.yaml
```

See `k8s/deployment.yaml` for full spec including:
- PodSecurityPolicy (restricted)
- NetworkPolicy (egress limited)
- Secrets management (external-secrets operator)

---

## Board Deliberation Notes

**From gpt_duck (pattern_analyst)**:
> Positive market fit. High-demand feature, but massive data acquisition risk.
> Requires explicit, granular user consent. Initial target: internal testing only.

**From claude_prime (verification_node)**:
> High-risk flag. Direct conflict with GDPR/CCPA if implemented naively.
> Zero-knowledge encryption is mandatory before any external data ingress.

**From claude_parallel (deep_architect)**:
> Tech feasibility: High. Needs specialized vector store and on-device transcription.
> Recommend NATS JetStream for high-volume audio processing pipeline.

**From grok_guardian (boundary_enforcer)**:
> Conditional approval. Passes OPA unsafe_action check.
> Requires Privacy Impact Assessment before prototype maturity level.

---

## Related Ideas

- **IDEA_026**: Code-to-Diagram Translator
- **IDEA_022**: API Aggregation Layer
- **IDEA_027**: Knowledge Graveyard Curator

---

## License

MIT — StrategicKhaos DAO LLC

---

*Part of the StrategicKhaos Swarm Intelligence ecosystem*  
*Wyoming Entity ID: 2025-001708194*  
*Board Deliberation: November 30, 2025*
