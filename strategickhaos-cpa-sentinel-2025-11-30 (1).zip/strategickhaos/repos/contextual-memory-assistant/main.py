#!/usr/bin/env python3
"""
Contextual Memory Assistant
IDEA_001 | StrategicKhaos Swarm Intelligence

Privacy-first knowledge graph assistant with zero-knowledge encryption.
Board-mandated gates: PIA required, zero-knowledge encryption enforced.
"""

import os
import json
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict, field
from enum import Enum

import typer
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.security import HTTPBearer
from pydantic import BaseModel
import uvicorn

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
CONSENT_FILE = Path(os.getenv("CONSENT_FILE", "~/.contextual-memory/consent.json")).expanduser()
LOCAL_ONLY = os.getenv("LOCAL_ONLY", "false").lower() == "true"
RETENTION_DAYS = int(os.getenv("RETENTION_DAYS", 365))

# Board-mandated gates
PIA_APPROVED = os.getenv("PIA_APPROVED", "false").lower() == "true"
ZK_ENCRYPTION_CONFIRMED = os.getenv("ZK_ENCRYPTION_CONFIRMED", "false").lower() == "true"

# ═══════════════════════════════════════════════════════════════════════════════
# GATE ENFORCEMENT
# ═══════════════════════════════════════════════════════════════════════════════

def check_deployment_gates():
    """Enforce board-mandated deployment gates."""
    gates_passed = True
    issues = []
    
    if not PIA_APPROVED:
        issues.append("Privacy Impact Assessment (PIA) not approved")
        gates_passed = False
    
    if not ZK_ENCRYPTION_CONFIRMED:
        issues.append("Zero-knowledge encryption not confirmed")
        gates_passed = False
    
    if not gates_passed:
        print("=" * 60)
        print("⛔ DEPLOYMENT BLOCKED — BOARD GATES NOT CLEARED")
        print("=" * 60)
        for issue in issues:
            print(f"  ❌ {issue}")
        print()
        print("Set the following environment variables after human approval:")
        print("  PIA_APPROVED=true")
        print("  ZK_ENCRYPTION_CONFIRMED=true")
        print("=" * 60)
        return False
    
    return True

# ═══════════════════════════════════════════════════════════════════════════════
# CONSENT MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════════

class ConsentScope(str, Enum):
    AUDIO_RECORDING = "audio_recording"
    TEXT_ANALYSIS = "text_analysis"
    KNOWLEDGE_GRAPH = "knowledge_graph"
    CLOUD_SYNC = "cloud_sync"

@dataclass
class ConsentRecord:
    scope: str
    granted: bool
    granted_at: Optional[str] = None
    expires_at: Optional[str] = None
    description: str = ""
    
class ConsentManager:
    """Manages user consent for data processing."""
    
    def __init__(self, consent_file: Path = CONSENT_FILE):
        self.consent_file = consent_file
        self.consent_file.parent.mkdir(parents=True, exist_ok=True)
        self._load()
    
    def _load(self):
        if self.consent_file.exists():
            with open(self.consent_file) as f:
                self.consents = json.load(f)
        else:
            self.consents = {}
    
    def _save(self):
        with open(self.consent_file, "w") as f:
            json.dump(self.consents, f, indent=2)
    
    def has_consent(self, scope: str) -> bool:
        """Check if consent is granted and not expired."""
        if scope not in self.consents:
            return False
        
        record = self.consents[scope]
        if not record.get("granted", False):
            return False
        
        if record.get("expires_at"):
            expires = datetime.fromisoformat(record["expires_at"])
            if datetime.now() > expires:
                return False
        
        return True
    
    def grant_consent(
        self,
        scope: str,
        description: str,
        retention_days: int = RETENTION_DAYS
    ) -> ConsentRecord:
        """Grant consent for a specific scope."""
        now = datetime.now()
        record = {
            "scope": scope,
            "granted": True,
            "granted_at": now.isoformat(),
            "expires_at": (now + timedelta(days=retention_days)).isoformat(),
            "description": description
        }
        self.consents[scope] = record
        self._save()
        return ConsentRecord(**record)
    
    def revoke_consent(self, scope: str) -> bool:
        """Revoke consent for a specific scope."""
        if scope in self.consents:
            self.consents[scope]["granted"] = False
            self.consents[scope]["revoked_at"] = datetime.now().isoformat()
            self._save()
            return True
        return False
    
    def export_all(self) -> Dict[str, Any]:
        """Export all consent records (GDPR compliance)."""
        return {
            "exported_at": datetime.now().isoformat(),
            "consents": self.consents
        }
    
    def delete_all(self) -> bool:
        """Delete all consent records (right to be forgotten)."""
        self.consents = {}
        self._save()
        return True

# ═══════════════════════════════════════════════════════════════════════════════
# ENCRYPTION (Zero-Knowledge)
# ═══════════════════════════════════════════════════════════════════════════════

class ZeroKnowledgeEncryption:
    """
    Zero-knowledge encryption for user data.
    Server never sees plaintext or encryption keys.
    """
    
    def __init__(self, user_key: Optional[bytes] = None):
        try:
            from nacl.secret import SecretBox
            from nacl.pwhash import argon2id
            self.SecretBox = SecretBox
            self.argon2id = argon2id
            self.available = True
        except ImportError:
            self.available = False
            print("⚠️ pynacl not installed. Encryption disabled.")
        
        self.box = None
        if user_key and self.available:
            self.box = self.SecretBox(user_key)
    
    @classmethod
    def derive_key_from_password(cls, password: str, salt: bytes) -> bytes:
        """Derive encryption key from password using Argon2id."""
        try:
            from nacl.pwhash import argon2id
            return argon2id.kdf(
                size=32,
                password=password.encode(),
                salt=salt,
                opslimit=argon2id.OPSLIMIT_MODERATE,
                memlimit=argon2id.MEMLIMIT_MODERATE
            )
        except ImportError:
            # Fallback for development (NOT SECURE)
            return hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    
    def encrypt(self, data: bytes) -> bytes:
        """Encrypt data client-side."""
        if not self.available or not self.box:
            raise RuntimeError("Encryption not configured")
        return self.box.encrypt(data)
    
    def decrypt(self, encrypted: bytes) -> bytes:
        """Decrypt data client-side."""
        if not self.available or not self.box:
            raise RuntimeError("Encryption not configured")
        return self.box.decrypt(encrypted)

# ═══════════════════════════════════════════════════════════════════════════════
# MEMORY STORE
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Memory:
    id: str
    content_hash: str  # Hash of content (server never sees plaintext)
    encrypted_embedding: bytes  # Encrypted vector
    created_at: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
class MemoryStore:
    """
    Local memory store with optional encrypted cloud sync.
    Server only stores encrypted blobs; cannot decrypt.
    """
    
    def __init__(self, local_only: bool = LOCAL_ONLY):
        self.local_only = local_only
        self.memories: Dict[str, Memory] = {}
        self.local_file = CONSENT_FILE.parent / "memories.json"
        self._load()
    
    def _load(self):
        if self.local_file.exists():
            with open(self.local_file) as f:
                data = json.load(f)
                for mid, mem in data.items():
                    # Convert encrypted_embedding from hex back to bytes
                    mem["encrypted_embedding"] = bytes.fromhex(mem["encrypted_embedding"])
                    self.memories[mid] = Memory(**mem)
    
    def _save(self):
        data = {}
        for mid, mem in self.memories.items():
            d = asdict(mem)
            # Convert bytes to hex for JSON serialization
            d["encrypted_embedding"] = mem.encrypted_embedding.hex()
            data[mid] = d
        with open(self.local_file, "w") as f:
            json.dump(data, f, indent=2)
    
    def store(self, memory: Memory) -> str:
        """Store an encrypted memory."""
        self.memories[memory.id] = memory
        self._save()
        return memory.id
    
    def query(self, query_embedding: bytes, top_k: int = 5) -> List[Memory]:
        """Query memories by similarity (simplified for local-only mode)."""
        # In production, this would use Qdrant with encrypted vectors
        # For now, return most recent memories
        sorted_mems = sorted(
            self.memories.values(),
            key=lambda m: m.created_at,
            reverse=True
        )
        return sorted_mems[:top_k]
    
    def delete_all(self) -> int:
        """Delete all memories (right to be forgotten)."""
        count = len(self.memories)
        self.memories = {}
        self._save()
        return count
    
    def export_all(self) -> Dict[str, Any]:
        """Export all memories (GDPR compliance)."""
        return {
            "exported_at": datetime.now().isoformat(),
            "memory_count": len(self.memories),
            "memories": [asdict(m) for m in self.memories.values()]
        }

# ═══════════════════════════════════════════════════════════════════════════════
# EMBEDDING GENERATION (Local)
# ═══════════════════════════════════════════════════════════════════════════════

class LocalEmbedder:
    """Generate embeddings locally (never send plaintext to server)."""
    
    def __init__(self):
        self.model = None
    
    def _load_model(self):
        if self.model is None:
            try:
                from sentence_transformers import SentenceTransformer
                self.model = SentenceTransformer('all-MiniLM-L6-v2')
            except ImportError:
                print("⚠️ sentence-transformers not installed")
                self.model = "stub"
    
    def embed(self, text: str) -> bytes:
        """Generate embedding locally."""
        self._load_model()
        
        if self.model == "stub":
            # Fallback for development
            return hashlib.sha256(text.encode()).digest()
        
        embedding = self.model.encode(text)
        return embedding.tobytes()

# ═══════════════════════════════════════════════════════════════════════════════
# API MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class ConsentRequest(BaseModel):
    scope: str
    description: str
    retention_days: int = 365

class IngestRequest(BaseModel):
    content: str  # Will be encrypted client-side in production
    metadata: Dict[str, Any] = {}

class QueryRequest(BaseModel):
    query: str
    top_k: int = 5

class HealthResponse(BaseModel):
    status: str
    idea_id: str
    gates: Dict[str, bool]
    local_only: bool

# ═══════════════════════════════════════════════════════════════════════════════
# API
# ═══════════════════════════════════════════════════════════════════════════════

app = FastAPI(
    title="Contextual Memory Assistant",
    description="IDEA_001 — StrategicKhaos Swarm Intelligence (Privacy-First)",
    version="0.1.0"
)

consent_manager = ConsentManager()
memory_store = MemoryStore()
embedder = LocalEmbedder()
security = HTTPBearer(auto_error=False)

def require_consent(scope: str):
    """Dependency to check consent."""
    def check():
        if not consent_manager.has_consent(scope):
            raise HTTPException(
                status_code=403,
                detail=f"Consent required for scope: {scope}"
            )
    return check

@app.get("/health", response_model=HealthResponse)
async def health():
    """Health check with gate status."""
    return HealthResponse(
        status="healthy",
        idea_id="IDEA_001",
        gates={
            "pia_approved": PIA_APPROVED,
            "zk_encryption_confirmed": ZK_ENCRYPTION_CONFIRMED
        },
        local_only=LOCAL_ONLY
    )

@app.get("/consent")
async def get_consent():
    """Get all consent records."""
    return consent_manager.export_all()

@app.post("/consent")
async def grant_consent(request: ConsentRequest):
    """Grant consent for a scope."""
    record = consent_manager.grant_consent(
        scope=request.scope,
        description=request.description,
        retention_days=request.retention_days
    )
    return asdict(record)

@app.delete("/consent/{scope}")
async def revoke_consent(scope: str):
    """Revoke consent for a scope."""
    if consent_manager.revoke_consent(scope):
        return {"status": "revoked", "scope": scope}
    raise HTTPException(status_code=404, detail="Consent not found")

@app.post("/ingest")
async def ingest_memory(
    request: IngestRequest,
    _: None = Depends(require_consent(ConsentScope.KNOWLEDGE_GRAPH.value))
):
    """Ingest a new memory (encrypted)."""
    # Generate embedding locally
    embedding = embedder.embed(request.content)
    
    # In production: encrypt with user's key before storage
    # For development: store as-is (NOT SECURE)
    memory = Memory(
        id=hashlib.sha256(request.content.encode()).hexdigest()[:16],
        content_hash=hashlib.sha256(request.content.encode()).hexdigest(),
        encrypted_embedding=embedding,
        created_at=datetime.now().isoformat(),
        metadata=request.metadata
    )
    
    memory_id = memory_store.store(memory)
    return {"status": "ingested", "memory_id": memory_id}

@app.post("/query")
async def query_memories(
    request: QueryRequest,
    _: None = Depends(require_consent(ConsentScope.KNOWLEDGE_GRAPH.value))
):
    """Query the knowledge graph."""
    query_embedding = embedder.embed(request.query)
    memories = memory_store.query(query_embedding, request.top_k)
    
    return {
        "query": request.query,
        "results": [
            {
                "id": m.id,
                "created_at": m.created_at,
                "metadata": m.metadata
                # Note: content not returned (server doesn't have plaintext)
            }
            for m in memories
        ]
    }

@app.get("/export")
async def export_data(
    _: None = Depends(require_consent(ConsentScope.KNOWLEDGE_GRAPH.value))
):
    """Export all user data (GDPR compliance)."""
    return {
        "consent": consent_manager.export_all(),
        "memories": memory_store.export_all()
    }

@app.delete("/delete-all")
async def delete_all_data():
    """Delete all user data (right to be forgotten)."""
    consent_manager.delete_all()
    memory_count = memory_store.delete_all()
    return {
        "status": "deleted",
        "memories_deleted": memory_count
    }

# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

cli = typer.Typer(help="Contextual Memory Assistant — IDEA_001")

@cli.command()
def serve(
    port: int = typer.Option(8000, "--port", "-p"),
    host: str = typer.Option("0.0.0.0", "--host", "-h")
):
    """Start API server."""
    if not check_deployment_gates():
        raise typer.Exit(code=1)
    
    typer.echo(f"Starting server at http://{host}:{port}")
    uvicorn.run(app, host=host, port=port)

@cli.command()
def local(
    consent_file: Optional[Path] = typer.Option(None, "--consent-file")
):
    """Run in local-only mode."""
    global LOCAL_ONLY
    LOCAL_ONLY = True
    
    typer.echo("Running in local-only mode (no server sync)")
    typer.echo(f"Consent file: {consent_file or CONSENT_FILE}")
    typer.echo("Ready for memory ingestion.")

@cli.command()
def query(text: str):
    """Query the knowledge graph."""
    embedding = embedder.embed(text)
    memories = memory_store.query(embedding)
    
    if not memories:
        typer.echo("No memories found.")
        return
    
    typer.echo(f"Found {len(memories)} memories:")
    for mem in memories:
        typer.echo(f"  - {mem.id} ({mem.created_at})")

@cli.command()
def consent(
    grant: Optional[str] = typer.Option(None, "--grant"),
    revoke: Optional[str] = typer.Option(None, "--revoke"),
    export: bool = typer.Option(False, "--export"),
    delete_all: bool = typer.Option(False, "--delete-all")
):
    """Manage consent."""
    if grant:
        record = consent_manager.grant_consent(
            scope=grant,
            description=f"Consent for {grant}",
            retention_days=RETENTION_DAYS
        )
        typer.echo(f"Granted consent: {grant}")
    
    if revoke:
        if consent_manager.revoke_consent(revoke):
            typer.echo(f"Revoked consent: {revoke}")
        else:
            typer.echo(f"Consent not found: {revoke}")
    
    if export:
        data = consent_manager.export_all()
        typer.echo(json.dumps(data, indent=2))
    
    if delete_all:
        consent_manager.delete_all()
        memory_store.delete_all()
        typer.echo("All data deleted.")

@cli.command()
def gates():
    """Check deployment gate status."""
    check_deployment_gates()

# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    cli()
