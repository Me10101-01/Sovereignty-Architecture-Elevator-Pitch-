# Code-to-Diagram Translator

> **IDEA_026** | Category: `devtools-utilities` | Priority: `critical`  
> **Bloom's Level**: 6-Create | **Video Module**: Q034  
> **Namespace**: `ns-infra` | **Service**: `svc-code-diagram`

## Overview

Tool that ingests source code and generates living architecture diagrams that update automatically as the codebase evolves. Supports Python, JavaScript, Go, and TypeScript.

**Alignment**: Self-documenting infrastructure goal. KnowledgePod demo candidate.

## Features

- **AST Parsing**: Extract structure from Python, JS, Go, TS
- **Dependency Graph**: Map imports, function calls, class hierarchies
- **Mermaid Output**: Generate Mermaid diagrams for GitHub/Obsidian rendering
- **GraphViz Output**: Generate DOT files for complex visualizations
- **Watch Mode**: Auto-regenerate on file changes
- **API Mode**: REST endpoint for CI/CD integration

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Source Code   │────▶│   AST Parser    │────▶│  Graph Builder  │
│  (py/js/go/ts)  │     │   (tree-sitter) │     │   (networkx)    │
└─────────────────┘     └─────────────────┘     └────────┬────────┘
                                                         │
                        ┌─────────────────┐     ┌────────▼────────┐
                        │  Diagram Output │◀────│   Renderer      │
                        │ (mermaid/dot)   │     │ (jinja2 tmpl)   │
                        └─────────────────┘     └─────────────────┘
```

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run on single file
python main.py analyze path/to/file.py

# Run on directory
python main.py analyze path/to/repo/ --recursive

# Watch mode
python main.py watch path/to/repo/ --output diagrams/

# API mode
python main.py serve --port 8000
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/analyze` | POST | Analyze code, return diagram |
| `/analyze/file` | POST | Upload file for analysis |
| `/analyze/repo` | POST | Analyze git repo URL |

### Example Request

```bash
curl -X POST http://localhost:8000/analyze \
  -H "Content-Type: application/json" \
  -d '{"code": "def hello(): print(\"world\")", "language": "python", "format": "mermaid"}'
```

### Example Response

```json
{
  "diagram": "graph TD\n    A[hello] --> B[print]",
  "format": "mermaid",
  "nodes": 2,
  "edges": 1,
  "language": "python"
}
```

## Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `OLLAMA_URL` | `http://localhost:11434` | Ollama API for AI-assisted analysis |
| `OUTPUT_FORMAT` | `mermaid` | Default output: `mermaid`, `dot`, `json` |
| `MAX_FILE_SIZE` | `1048576` | Max file size in bytes (1MB) |
| `WATCH_INTERVAL` | `2` | Seconds between watch checks |

## Kubernetes Deployment

```bash
kubectl apply -f k8s/deployment.yaml
```

See `k8s/deployment.yaml` for full spec.

## Integration with KnowledgePods

This service is designed to integrate with the KnowledgePod CRD:

```yaml
apiVersion: strategickhaos.io/v1
kind: KnowledgePod
metadata:
  name: code-diagram-demo
spec:
  questionId: Q034
  videoRef: "videos/Q034-code-to-diagram.mp4"
  markdownRef: "docs/Q034-code-to-diagram.md"
  serviceRef: "svc-code-diagram"
  interactiveDemo: true
```

## Dependencies

- `tree-sitter` — Multi-language AST parsing
- `networkx` — Graph construction
- `jinja2` — Template rendering
- `fastapi` — API framework
- `uvicorn` — ASGI server
- `watchdog` — File system monitoring

## License

MIT — StrategicKhaos DAO LLC

## Related Ideas

- **IDEA_027**: Knowledge Graveyard Curator
- **IDEA_022**: API Aggregation Layer
- **IDEA_081**: No-Code API Generator from Spreadsheets

---

*Part of the StrategicKhaos Swarm Intelligence ecosystem*  
*Wyoming Entity ID: 2025-001708194*
