#!/usr/bin/env python3
"""
Code-to-Diagram Translator
IDEA_026 | StrategicKhaos Swarm Intelligence

Ingests source code and generates living architecture diagrams.
"""

import os
import ast
import json
import asyncio
from pathlib import Path
from typing import Optional, Literal
from dataclasses import dataclass, asdict
from enum import Enum

import typer
import networkx as nx
from fastapi import FastAPI, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
import uvicorn

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OUTPUT_FORMAT = os.getenv("OUTPUT_FORMAT", "mermaid")
MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", 1048576))
WATCH_INTERVAL = int(os.getenv("WATCH_INTERVAL", 2))

# ═══════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class OutputFormat(str, Enum):
    MERMAID = "mermaid"
    DOT = "dot"
    JSON = "json"

class Language(str, Enum):
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    GO = "go"

@dataclass
class Node:
    id: str
    name: str
    type: str  # function, class, module, import
    line_start: int = 0
    line_end: int = 0

@dataclass
class Edge:
    source: str
    target: str
    type: str  # calls, imports, inherits

@dataclass
class CodeGraph:
    nodes: list[Node]
    edges: list[Edge]
    language: str
    source_file: str

class AnalyzeRequest(BaseModel):
    code: str
    language: Language = Language.PYTHON
    format: OutputFormat = OutputFormat.MERMAID

class AnalyzeResponse(BaseModel):
    diagram: str
    format: str
    nodes: int
    edges: int
    language: str

# ═══════════════════════════════════════════════════════════════════════════════
# PARSERS
# ═══════════════════════════════════════════════════════════════════════════════

class PythonParser:
    """Parse Python AST to extract structure."""
    
    def parse(self, code: str, filename: str = "<string>") -> CodeGraph:
        nodes = []
        edges = []
        
        try:
            tree = ast.parse(code, filename=filename)
        except SyntaxError as e:
            raise ValueError(f"Syntax error: {e}")
        
        # Extract imports
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    nodes.append(Node(
                        id=f"import_{alias.name}",
                        name=alias.name,
                        type="import",
                        line_start=node.lineno
                    ))
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    full_name = f"{module}.{alias.name}" if module else alias.name
                    nodes.append(Node(
                        id=f"import_{full_name}",
                        name=full_name,
                        type="import",
                        line_start=node.lineno
                    ))
        
        # Extract classes and functions
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                class_node = Node(
                    id=f"class_{node.name}",
                    name=node.name,
                    type="class",
                    line_start=node.lineno,
                    line_end=node.end_lineno or node.lineno
                )
                nodes.append(class_node)
                
                # Check for inheritance
                for base in node.bases:
                    if isinstance(base, ast.Name):
                        edges.append(Edge(
                            source=f"class_{node.name}",
                            target=f"class_{base.id}",
                            type="inherits"
                        ))
                
                # Extract methods
                for item in node.body:
                    if isinstance(item, ast.FunctionDef):
                        method_id = f"method_{node.name}_{item.name}"
                        nodes.append(Node(
                            id=method_id,
                            name=f"{node.name}.{item.name}",
                            type="method",
                            line_start=item.lineno,
                            line_end=item.end_lineno or item.lineno
                        ))
                        edges.append(Edge(
                            source=f"class_{node.name}",
                            target=method_id,
                            type="contains"
                        ))
            
            elif isinstance(node, ast.FunctionDef):
                # Top-level functions only
                if not any(isinstance(p, ast.ClassDef) for p in ast.walk(tree)):
                    nodes.append(Node(
                        id=f"func_{node.name}",
                        name=node.name,
                        type="function",
                        line_start=node.lineno,
                        line_end=node.end_lineno or node.lineno
                    ))
        
        # Extract function calls
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                caller = self._get_enclosing_function(tree, node)
                if caller and isinstance(node.func, ast.Name):
                    edges.append(Edge(
                        source=f"func_{caller}",
                        target=f"func_{node.func.id}",
                        type="calls"
                    ))
        
        return CodeGraph(
            nodes=nodes,
            edges=edges,
            language="python",
            source_file=filename
        )
    
    def _get_enclosing_function(self, tree: ast.AST, target: ast.AST) -> Optional[str]:
        """Find the function containing this node."""
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                if hasattr(node, 'lineno') and hasattr(target, 'lineno'):
                    if node.lineno <= target.lineno <= (node.end_lineno or node.lineno):
                        return node.name
        return None

# ═══════════════════════════════════════════════════════════════════════════════
# RENDERERS
# ═══════════════════════════════════════════════════════════════════════════════

class MermaidRenderer:
    """Render CodeGraph to Mermaid diagram."""
    
    def render(self, graph: CodeGraph) -> str:
        lines = ["graph TD"]
        
        # Render nodes
        for node in graph.nodes:
            shape = self._get_shape(node.type)
            lines.append(f"    {node.id}{shape[0]}{node.name}{shape[1]}")
        
        # Render edges
        for edge in graph.edges:
            arrow = self._get_arrow(edge.type)
            lines.append(f"    {edge.source} {arrow} {edge.target}")
        
        return "\n".join(lines)
    
    def _get_shape(self, node_type: str) -> tuple[str, str]:
        shapes = {
            "class": ("[", "]"),
            "function": ("(", ")"),
            "method": ("([", "])"),
            "import": ("{{", "}}"),
            "module": ("[[", "]]")
        }
        return shapes.get(node_type, ("[", "]"))
    
    def _get_arrow(self, edge_type: str) -> str:
        arrows = {
            "calls": "-->",
            "imports": "-.->",
            "inherits": "===>",
            "contains": "-->"
        }
        return arrows.get(edge_type, "-->")

class DotRenderer:
    """Render CodeGraph to GraphViz DOT format."""
    
    def render(self, graph: CodeGraph) -> str:
        lines = [
            "digraph CodeDiagram {",
            "    rankdir=TB;",
            "    node [fontname=\"Arial\"];",
            ""
        ]
        
        # Group by type
        by_type = {}
        for node in graph.nodes:
            by_type.setdefault(node.type, []).append(node)
        
        # Render subgraphs
        for node_type, nodes in by_type.items():
            lines.append(f"    subgraph cluster_{node_type} {{")
            lines.append(f"        label=\"{node_type.title()}s\";")
            for node in nodes:
                shape = self._get_shape(node_type)
                lines.append(f"        {node.id} [label=\"{node.name}\", shape={shape}];")
            lines.append("    }")
            lines.append("")
        
        # Render edges
        for edge in graph.edges:
            style = self._get_style(edge.type)
            lines.append(f"    {edge.source} -> {edge.target} [{style}];")
        
        lines.append("}")
        return "\n".join(lines)
    
    def _get_shape(self, node_type: str) -> str:
        shapes = {
            "class": "box",
            "function": "ellipse",
            "method": "oval",
            "import": "parallelogram",
            "module": "box3d"
        }
        return shapes.get(node_type, "box")
    
    def _get_style(self, edge_type: str) -> str:
        styles = {
            "calls": "style=solid",
            "imports": "style=dashed",
            "inherits": "style=bold",
            "contains": "style=dotted"
        }
        return styles.get(edge_type, "style=solid")

class JsonRenderer:
    """Render CodeGraph to JSON."""
    
    def render(self, graph: CodeGraph) -> str:
        return json.dumps({
            "nodes": [asdict(n) for n in graph.nodes],
            "edges": [asdict(e) for e in graph.edges],
            "language": graph.language,
            "source_file": graph.source_file
        }, indent=2)

# ═══════════════════════════════════════════════════════════════════════════════
# ANALYZER
# ═══════════════════════════════════════════════════════════════════════════════

class CodeAnalyzer:
    """Main analyzer that coordinates parsing and rendering."""
    
    def __init__(self):
        self.parsers = {
            Language.PYTHON: PythonParser(),
            # TODO: Add JavaScript, TypeScript, Go parsers
        }
        self.renderers = {
            OutputFormat.MERMAID: MermaidRenderer(),
            OutputFormat.DOT: DotRenderer(),
            OutputFormat.JSON: JsonRenderer()
        }
    
    def analyze(
        self,
        code: str,
        language: Language = Language.PYTHON,
        output_format: OutputFormat = OutputFormat.MERMAID,
        filename: str = "<string>"
    ) -> tuple[str, CodeGraph]:
        parser = self.parsers.get(language)
        if not parser:
            raise ValueError(f"Unsupported language: {language}")
        
        renderer = self.renderers.get(output_format)
        if not renderer:
            raise ValueError(f"Unsupported format: {output_format}")
        
        graph = parser.parse(code, filename)
        diagram = renderer.render(graph)
        
        return diagram, graph
    
    def analyze_file(
        self,
        filepath: Path,
        output_format: OutputFormat = OutputFormat.MERMAID
    ) -> tuple[str, CodeGraph]:
        if not filepath.exists():
            raise FileNotFoundError(f"File not found: {filepath}")
        
        if filepath.stat().st_size > MAX_FILE_SIZE:
            raise ValueError(f"File too large: {filepath.stat().st_size} bytes")
        
        code = filepath.read_text()
        language = self._detect_language(filepath)
        
        return self.analyze(code, language, output_format, str(filepath))
    
    def _detect_language(self, filepath: Path) -> Language:
        ext_map = {
            ".py": Language.PYTHON,
            ".js": Language.JAVASCRIPT,
            ".ts": Language.TYPESCRIPT,
            ".go": Language.GO
        }
        return ext_map.get(filepath.suffix, Language.PYTHON)

# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

cli = typer.Typer(help="Code-to-Diagram Translator — IDEA_026")
analyzer = CodeAnalyzer()

@cli.command()
def analyze(
    path: Path = typer.Argument(..., help="File or directory to analyze"),
    recursive: bool = typer.Option(False, "--recursive", "-r", help="Analyze recursively"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output directory"),
    format: OutputFormat = typer.Option(OutputFormat.MERMAID, "--format", "-f", help="Output format")
):
    """Analyze code and generate diagrams."""
    if path.is_file():
        diagram, graph = analyzer.analyze_file(path, format)
        if output:
            output.mkdir(parents=True, exist_ok=True)
            out_file = output / f"{path.stem}.{format.value}"
            out_file.write_text(diagram)
            typer.echo(f"Generated: {out_file}")
        else:
            typer.echo(diagram)
    elif path.is_dir():
        patterns = ["*.py", "*.js", "*.ts", "*.go"]
        glob_method = path.rglob if recursive else path.glob
        for pattern in patterns:
            for file in glob_method(pattern):
                try:
                    diagram, graph = analyzer.analyze_file(file, format)
                    if output:
                        output.mkdir(parents=True, exist_ok=True)
                        out_file = output / f"{file.stem}.{format.value}"
                        out_file.write_text(diagram)
                        typer.echo(f"Generated: {out_file}")
                except Exception as e:
                    typer.echo(f"Error: {file}: {e}", err=True)

@cli.command()
def watch(
    path: Path = typer.Argument(..., help="Directory to watch"),
    output: Path = typer.Option(Path("diagrams"), "--output", "-o", help="Output directory"),
    format: OutputFormat = typer.Option(OutputFormat.MERMAID, "--format", "-f", help="Output format")
):
    """Watch directory and regenerate diagrams on changes."""
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    
    class DiagramHandler(FileSystemEventHandler):
        def on_modified(self, event):
            if event.is_directory:
                return
            filepath = Path(event.src_path)
            if filepath.suffix in [".py", ".js", ".ts", ".go"]:
                try:
                    diagram, _ = analyzer.analyze_file(filepath, format)
                    output.mkdir(parents=True, exist_ok=True)
                    out_file = output / f"{filepath.stem}.{format.value}"
                    out_file.write_text(diagram)
                    typer.echo(f"Updated: {out_file}")
                except Exception as e:
                    typer.echo(f"Error: {filepath}: {e}", err=True)
    
    observer = Observer()
    observer.schedule(DiagramHandler(), str(path), recursive=True)
    observer.start()
    typer.echo(f"Watching {path}... (Ctrl+C to stop)")
    
    try:
        while True:
            asyncio.run(asyncio.sleep(WATCH_INTERVAL))
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

@cli.command()
def serve(
    port: int = typer.Option(8000, "--port", "-p", help="Port to listen on"),
    host: str = typer.Option("0.0.0.0", "--host", "-h", help="Host to bind to")
):
    """Start API server."""
    typer.echo(f"Starting server at http://{host}:{port}")
    uvicorn.run(app, host=host, port=port)

# ═══════════════════════════════════════════════════════════════════════════════
# API
# ═══════════════════════════════════════════════════════════════════════════════

app = FastAPI(
    title="Code-to-Diagram Translator",
    description="IDEA_026 — StrategicKhaos Swarm Intelligence",
    version="0.1.0"
)

@app.get("/health")
async def health():
    return {"status": "healthy", "idea_id": "IDEA_026"}

@app.post("/analyze", response_model=AnalyzeResponse)
async def api_analyze(request: AnalyzeRequest):
    try:
        diagram, graph = analyzer.analyze(
            request.code,
            request.language,
            request.format
        )
        return AnalyzeResponse(
            diagram=diagram,
            format=request.format.value,
            nodes=len(graph.nodes),
            edges=len(graph.edges),
            language=graph.language
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/analyze/example", response_class=PlainTextResponse)
async def api_example():
    """Return example diagram from sample code."""
    sample = '''
class Animal:
    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        return "woof"
    
    def fetch(self):
        return "ball"

def main():
    dog = Dog()
    dog.speak()
    dog.fetch()
'''
    diagram, _ = analyzer.analyze(sample, Language.PYTHON, OutputFormat.MERMAID)
    return diagram

# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    cli()
