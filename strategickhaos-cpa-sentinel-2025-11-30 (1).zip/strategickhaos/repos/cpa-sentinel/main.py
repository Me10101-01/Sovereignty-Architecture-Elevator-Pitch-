#!/usr/bin/env python3
"""
CPA Sentinel — Compliance, Protection & Audit Department
IDEA_100 | StrategicKhaos Swarm Intelligence

Monitors emails, finances, brand, and credit across all DAO entities.
"""

import os
import json
import hashlib
import asyncio
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict, field
from enum import Enum
from pathlib import Path

import typer
from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
import uvicorn

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

NATS_URL = os.getenv("NATS_URL", "nats://localhost:4222")
QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

# API Keys (load from secrets in production)
STRIPE_API_KEY = os.getenv("STRIPE_API_KEY", "")
PLAID_CLIENT_ID = os.getenv("PLAID_CLIENT_ID", "")
PLAID_SECRET = os.getenv("PLAID_SECRET", "")
SEQUENCE_API_KEY = os.getenv("SEQUENCE_API_KEY", "")

# Entity Configuration
ENTITIES = {
    "strategickhaos_dao": {
        "name": "StrategicKhaos DAO LLC",
        "jurisdiction": "Wyoming",
        "entity_id": "2025-001708194",
        "type": "LLC"
    },
    "valoryield": {
        "name": "ValorYield Engine",
        "ein": "39-2923503",
        "type": "501(c)(3)"
    }
}

# Brand Watch Terms
BRAND_WATCH_TERMS = [
    "StrategicKhaos", "Strategic Khaos", "StrategicChaos",
    "ValorYield", "Valor Yield",
    "Me10101", "Dom Garza", "Domenic Garza"
]

# Proofpoint Whitelist
PROOFPOINT_WHITELIST = [
    "team@email.anthropic.com",
    "noreply@x.ai",
    "learn@send.zapier.com",
    "brokerage@ninjatrader.com",
    "crew@hackthebox.com",
    "clientservices@ninjatrader.com",
    "no-reply@getsequence.io",
    "noreply@email.openai.com",
    "no-reply@docker.com",
    "MSDyn365@email.microsoft.com"
]

# ═══════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class AlertSeverity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    URGENT = "urgent"

class AlertCategory(str, Enum):
    EMAIL = "email"
    FINANCE = "finance"
    BRAND = "brand"
    CREDIT = "credit"
    SECURITY = "security"
    LEGAL = "legal"

@dataclass
class Alert:
    id: str
    category: str
    severity: str
    title: str
    description: str
    source: str
    timestamp: str
    entity: Optional[str] = None
    action_required: bool = False
    action_url: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class EmailSummary:
    account: str
    unread_count: int
    urgent_count: int
    categories: Dict[str, int]
    recent: List[Dict[str, Any]]

@dataclass
class FinancialSummary:
    total_balance: float
    accounts: List[Dict[str, Any]]
    recent_transactions: List[Dict[str, Any]]
    pending_payouts: float
    monthly_revenue: float
    monthly_expenses: float

@dataclass
class BrandAlert:
    term: str
    source: str
    url: str
    snippet: str
    sentiment: str
    timestamp: str
    threat_level: str

# ═══════════════════════════════════════════════════════════════════════════════
# EMAIL AGGREGATOR
# ═══════════════════════════════════════════════════════════════════════════════

class EmailAggregator:
    """Aggregates emails from multiple accounts."""
    
    def __init__(self):
        self.accounts = []
    
    async def add_outlook_account(self, email: str, credentials: Dict):
        """Add Outlook/Office365 account."""
        # In production: Use Microsoft Graph API
        self.accounts.append({
            "type": "outlook",
            "email": email,
            "status": "connected"
        })
    
    async def add_gmail_account(self, email: str, credentials_file: str):
        """Add Gmail account."""
        # In production: Use Gmail API with OAuth
        self.accounts.append({
            "type": "gmail",
            "email": email,
            "status": "connected"
        })
    
    async def get_unified_inbox(self, limit: int = 50) -> List[Dict]:
        """Get unified inbox from all accounts."""
        # Placeholder - implement with actual APIs
        return []
    
    async def triage_email(self, email: Dict) -> Dict:
        """AI-powered email categorization."""
        # Categories: legal, finance, security, ops, marketing, spam
        # In production: Use LLM for categorization
        return {
            "email_id": email.get("id"),
            "category": "ops",
            "priority": "normal",
            "suggested_action": "review"
        }
    
    def check_whitelist(self, sender: str) -> bool:
        """Check if sender is whitelisted."""
        return sender.lower() in [w.lower() for w in PROOFPOINT_WHITELIST]

# ═══════════════════════════════════════════════════════════════════════════════
# FINANCIAL MONITOR
# ═══════════════════════════════════════════════════════════════════════════════

class FinancialMonitor:
    """Monitors all financial accounts."""
    
    def __init__(self):
        self.stripe_connected = bool(STRIPE_API_KEY)
        self.plaid_connected = bool(PLAID_CLIENT_ID and PLAID_SECRET)
        self.sequence_connected = bool(SEQUENCE_API_KEY)
    
    async def get_stripe_summary(self) -> Dict:
        """Get Stripe account summary."""
        if not self.stripe_connected:
            return {"status": "not_connected"}
        
        # In production: Use stripe-python
        # import stripe
        # stripe.api_key = STRIPE_API_KEY
        # balance = stripe.Balance.retrieve()
        return {
            "status": "connected",
            "balance": {"available": 0, "pending": 0},
            "recent_charges": []
        }
    
    async def get_plaid_accounts(self) -> List[Dict]:
        """Get bank accounts via Plaid."""
        if not self.plaid_connected:
            return []
        
        # In production: Use plaid-python
        return []
    
    async def get_sequence_summary(self) -> Dict:
        """Get Sequence.io business account summary."""
        if not self.sequence_connected:
            return {"status": "not_connected"}
        
        # In production: Use Sequence API
        return {
            "status": "connected",
            "business_name": "StrategicKhaos DAO LLC",
            "balance": 0,
            "pending_invoices": []
        }
    
    async def detect_anomalies(self, transactions: List[Dict]) -> List[Alert]:
        """Detect unusual transaction patterns."""
        alerts = []
        
        for tx in transactions:
            # Check for large transactions
            if tx.get("amount", 0) > 1000:
                alerts.append(Alert(
                    id=f"fin-{tx.get('id', 'unknown')}",
                    category=AlertCategory.FINANCE.value,
                    severity=AlertSeverity.WARNING.value,
                    title="Large Transaction Detected",
                    description=f"Transaction of ${tx.get('amount')} detected",
                    source="financial_monitor",
                    timestamp=datetime.now().isoformat(),
                    action_required=True
                ))
        
        return alerts
    
    async def check_copycat_payments(self, description: str) -> bool:
        """Check if payment description might be a copycat."""
        for term in BRAND_WATCH_TERMS:
            if term.lower() in description.lower():
                return True
        return False

# ═══════════════════════════════════════════════════════════════════════════════
# BRAND PROTECTION
# ═══════════════════════════════════════════════════════════════════════════════

class BrandProtection:
    """Monitors for unauthorized brand usage."""
    
    def __init__(self):
        self.watch_terms = BRAND_WATCH_TERMS
        self.domains = [
            "strategickhaos.com",
            "strategickhaos.ai",
            "valoryield.org"
        ]
    
    async def check_uspto_tsdr(self) -> List[Dict]:
        """Check USPTO Trademark Status & Document Retrieval."""
        # In production: Use USPTO TSDR API
        # Monitor for:
        # 1. Status updates on your applications
        # 2. Similar marks being filed
        return []
    
    async def search_google_alerts(self) -> List[BrandAlert]:
        """Check Google Alerts for brand mentions."""
        # In production: Use Google Alerts API or scrape RSS
        return []
    
    async def search_twitter(self, term: str) -> List[Dict]:
        """Search Twitter/X for brand mentions."""
        # In production: Use Twitter API v2
        return []
    
    async def search_reddit(self, term: str) -> List[Dict]:
        """Search Reddit for brand mentions."""
        # In production: Use PRAW (Python Reddit API Wrapper)
        return []
    
    async def check_domain_squatting(self) -> List[Alert]:
        """Check for similar domain registrations."""
        alerts = []
        
        # Common typosquatting patterns
        variations = [
            "strategickhaos", "strategicchaos", "strategic-khaos",
            "strategickhaos", "strategickha0s", "strategickaos"
        ]
        
        tlds = [".com", ".net", ".org", ".io", ".ai", ".co"]
        
        # In production: Use WHOIS API to check each variation
        # dns.resolver or python-whois
        
        return alerts
    
    async def check_github_forks(self, repo: str) -> List[Dict]:
        """Monitor GitHub forks for unauthorized usage."""
        # In production: Use GitHub API
        return []
    
    async def generate_cease_desist_draft(self, infringement: Dict) -> str:
        """Generate cease & desist letter draft."""
        # DRAFT template - requires attorney review
        return f"""
CEASE AND DESIST NOTICE
DRAFT – Pending Legal Review

Date: {datetime.now().strftime('%B %d, %Y')}

To: {infringement.get('infringer_name', '[INFRINGER NAME]')}

RE: Unauthorized Use of StrategicKhaos Trademarks

Dear Sir/Madam,

This letter serves as formal notice that your use of [INFRINGING MARK/CONTENT] 
constitutes unauthorized use of trademarks and/or copyrights owned by 
StrategicKhaos DAO LLC.

[DETAILS OF INFRINGEMENT]

You are hereby demanded to:
1. Immediately cease all use of the infringing marks/content
2. Remove all infringing materials from all platforms
3. Confirm compliance within 10 business days

Failure to comply may result in legal action.

This is a DRAFT document generated automatically.
CONSULT WITH A LICENSED ATTORNEY BEFORE SENDING.

StrategicKhaos DAO LLC
Wyoming Entity ID: 2025-001708194
"""

# ═══════════════════════════════════════════════════════════════════════════════
# CREDIT MONITOR
# ═══════════════════════════════════════════════════════════════════════════════

class CreditMonitor:
    """Monitors business credit for all entities."""
    
    def __init__(self):
        self.entities = ENTITIES
    
    async def get_dnb_report(self, duns_number: str) -> Dict:
        """Get Dun & Bradstreet report."""
        # In production: Use D&B Direct+ API
        return {
            "duns_number": duns_number,
            "paydex_score": None,
            "status": "pending_registration"
        }
    
    async def get_experian_business(self, bin_number: str) -> Dict:
        """Get Experian Business Credit report."""
        # In production: Use Experian Business API
        return {
            "bin_number": bin_number,
            "intelliscore": None,
            "status": "pending_registration"
        }
    
    async def check_good_standing(self, entity_id: str, state: str) -> Dict:
        """Check entity good standing with state."""
        # In production: Query state SOS API
        if state.lower() == "wyoming":
            return {
                "entity_id": entity_id,
                "state": "Wyoming",
                "status": "good_standing",
                "last_checked": datetime.now().isoformat()
            }
        return {"status": "unknown"}

# ═══════════════════════════════════════════════════════════════════════════════
# VENDOR VERIFICATION
# ═══════════════════════════════════════════════════════════════════════════════

class VendorVerification:
    """Background checks for vendors and contractors."""
    
    async def check_ofac_sdn(self, name: str) -> Dict:
        """Check OFAC Specially Designated Nationals list."""
        # In production: Use OFAC SDN API
        # https://sanctionssearch.ofac.treas.gov/
        return {
            "name": name,
            "sdn_match": False,
            "checked_at": datetime.now().isoformat()
        }
    
    async def verify_business_registration(
        self, 
        business_name: str, 
        state: str
    ) -> Dict:
        """Verify business is registered in state."""
        # In production: Query state SOS database
        return {
            "business_name": business_name,
            "state": state,
            "verified": None,
            "status": "manual_check_required"
        }
    
    async def search_ucc_filings(self, name: str, state: str) -> List[Dict]:
        """Search UCC filings for liens."""
        # In production: Query state UCC database
        return []
    
    async def search_litigation(self, name: str) -> List[Dict]:
        """Search PACER for federal litigation."""
        # In production: Use PACER API
        # Note: Requires PACER account
        return []

# ═══════════════════════════════════════════════════════════════════════════════
# AUDIT TRAIL
# ═══════════════════════════════════════════════════════════════════════════════

class AuditTrail:
    """Cryptographic audit logging."""
    
    def __init__(self, log_dir: Path = Path("./audit_logs")):
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
    
    def log_action(self, action: Dict) -> str:
        """Log an action with hash."""
        action["timestamp"] = datetime.now().isoformat()
        action_json = json.dumps(action, sort_keys=True)
        action_hash = hashlib.sha256(action_json.encode()).hexdigest()
        
        log_entry = {
            "hash": action_hash,
            "action": action
        }
        
        # Append to daily log file
        date_str = datetime.now().strftime("%Y-%m-%d")
        log_file = self.log_dir / f"audit_{date_str}.jsonl"
        
        with open(log_file, "a") as f:
            f.write(json.dumps(log_entry) + "\n")
        
        return action_hash
    
    def verify_log(self, log_file: Path) -> bool:
        """Verify integrity of log file."""
        # In production: Verify Merkle tree and Sigstore signatures
        return True

# ═══════════════════════════════════════════════════════════════════════════════
# API MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class DashboardResponse(BaseModel):
    email_summary: Dict
    financial_summary: Dict
    brand_alerts: List[Dict]
    credit_status: Dict
    recent_audit_entries: List[Dict]

class VendorCheckRequest(BaseModel):
    name: str
    business_name: Optional[str] = None
    state: Optional[str] = None

class BrandWatchRequest(BaseModel):
    term: str

# ═══════════════════════════════════════════════════════════════════════════════
# API
# ═══════════════════════════════════════════════════════════════════════════════

app = FastAPI(
    title="CPA Sentinel",
    description="Compliance, Protection & Audit Department — IDEA_100",
    version="0.1.0"
)

# Initialize services
email_aggregator = EmailAggregator()
financial_monitor = FinancialMonitor()
brand_protection = BrandProtection()
credit_monitor = CreditMonitor()
vendor_verification = VendorVerification()
audit_trail = AuditTrail()

@app.get("/health")
async def health():
    """Health check."""
    return {
        "status": "healthy",
        "idea_id": "IDEA_100",
        "service": "cpa-sentinel",
        "integrations": {
            "stripe": financial_monitor.stripe_connected,
            "plaid": financial_monitor.plaid_connected,
            "sequence": financial_monitor.sequence_connected
        }
    }

@app.get("/dashboard")
async def get_dashboard():
    """Get unified CPA dashboard."""
    # Aggregate all data
    stripe_summary = await financial_monitor.get_stripe_summary()
    sequence_summary = await financial_monitor.get_sequence_summary()
    brand_alerts = await brand_protection.search_google_alerts()
    
    return {
        "timestamp": datetime.now().isoformat(),
        "entities": ENTITIES,
        "email": {
            "accounts": email_aggregator.accounts,
            "unread_urgent": 0
        },
        "finance": {
            "stripe": stripe_summary,
            "sequence": sequence_summary
        },
        "brand": {
            "watch_terms": BRAND_WATCH_TERMS,
            "alerts": [asdict(a) for a in brand_alerts]
        },
        "credit": {
            "entities": list(ENTITIES.keys()),
            "status": "monitoring"
        }
    }

@app.get("/email/aggregate")
async def get_email_aggregate(limit: int = 50):
    """Get aggregated emails from all accounts."""
    emails = await email_aggregator.get_unified_inbox(limit)
    return {"emails": emails, "count": len(emails)}

@app.get("/email/whitelist")
async def get_whitelist():
    """Get Proofpoint whitelist."""
    return {"whitelist": PROOFPOINT_WHITELIST}

@app.post("/email/whitelist")
async def add_to_whitelist(sender: str):
    """Add sender to whitelist."""
    if sender not in PROOFPOINT_WHITELIST:
        PROOFPOINT_WHITELIST.append(sender)
        audit_trail.log_action({
            "action": "whitelist_add",
            "sender": sender
        })
    return {"whitelist": PROOFPOINT_WHITELIST}

@app.get("/finance/summary")
async def get_finance_summary():
    """Get financial summary across all accounts."""
    stripe = await financial_monitor.get_stripe_summary()
    sequence = await financial_monitor.get_sequence_summary()
    plaid = await financial_monitor.get_plaid_accounts()
    
    return {
        "stripe": stripe,
        "sequence": sequence,
        "bank_accounts": plaid
    }

@app.get("/brand/alerts")
async def get_brand_alerts():
    """Get brand monitoring alerts."""
    google_alerts = await brand_protection.search_google_alerts()
    domain_alerts = await brand_protection.check_domain_squatting()
    
    return {
        "watch_terms": BRAND_WATCH_TERMS,
        "google_alerts": [asdict(a) for a in google_alerts],
        "domain_alerts": [asdict(a) for a in domain_alerts]
    }

@app.post("/brand/watch")
async def add_brand_watch(request: BrandWatchRequest):
    """Add term to brand watch list."""
    if request.term not in BRAND_WATCH_TERMS:
        BRAND_WATCH_TERMS.append(request.term)
        audit_trail.log_action({
            "action": "brand_watch_add",
            "term": request.term
        })
    return {"watch_terms": BRAND_WATCH_TERMS}

@app.get("/credit/report")
async def get_credit_report():
    """Get business credit summary for all entities."""
    reports = {}
    for entity_id, entity in ENTITIES.items():
        reports[entity_id] = {
            "entity": entity,
            "good_standing": await credit_monitor.check_good_standing(
                entity.get("entity_id", ""),
                entity.get("jurisdiction", "Wyoming")
            )
        }
    return reports

@app.post("/verify/vendor")
async def verify_vendor(request: VendorCheckRequest):
    """Run vendor background check."""
    audit_trail.log_action({
        "action": "vendor_check",
        "name": request.name
    })
    
    ofac_check = await vendor_verification.check_ofac_sdn(request.name)
    
    result = {
        "name": request.name,
        "ofac_sdn": ofac_check,
        "business_registration": None,
        "ucc_filings": [],
        "litigation": []
    }
    
    if request.business_name and request.state:
        result["business_registration"] = await vendor_verification.verify_business_registration(
            request.business_name,
            request.state
        )
    
    return result

@app.get("/audit/log")
async def get_audit_log(days: int = 7):
    """Get recent audit log entries."""
    entries = []
    for i in range(days):
        date = datetime.now() - timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        log_file = audit_trail.log_dir / f"audit_{date_str}.jsonl"
        
        if log_file.exists():
            with open(log_file) as f:
                for line in f:
                    entries.append(json.loads(line))
    
    return {"entries": entries, "count": len(entries)}

# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

cli = typer.Typer(help="CPA Sentinel — Compliance, Protection & Audit")

@cli.command()
def serve(
    port: int = typer.Option(8000, "--port", "-p"),
    host: str = typer.Option("0.0.0.0", "--host", "-h")
):
    """Start API server."""
    typer.echo(f"Starting CPA Sentinel at http://{host}:{port}")
    uvicorn.run(app, host=host, port=port)

@cli.command()
def check_brand(term: str):
    """Check for brand mentions."""
    typer.echo(f"Searching for: {term}")
    # Run async search
    import asyncio
    results = asyncio.run(brand_protection.search_google_alerts())
    typer.echo(f"Found {len(results)} mentions")

@cli.command()
def verify(name: str, business: Optional[str] = None, state: Optional[str] = None):
    """Run vendor verification."""
    import asyncio
    result = asyncio.run(vendor_verification.check_ofac_sdn(name))
    typer.echo(f"OFAC SDN Check: {result}")

@cli.command()
def whitelist_show():
    """Show Proofpoint whitelist."""
    for sender in PROOFPOINT_WHITELIST:
        typer.echo(f"  ✓ {sender}")

@cli.command()
def whitelist_add(sender: str):
    """Add sender to whitelist."""
    PROOFPOINT_WHITELIST.append(sender)
    typer.echo(f"Added: {sender}")

# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    cli()
