# 💜 ValorYield Sovereign Financial OS

**"Banking for the People, by the Code"**

A legally-recognized, AI-operated public benefit financial system built on Wyoming's pioneering DAO and Public Benefit Corporation statutes.

## 🏛️ Legal Foundation

This system operates under two legally-filed Wyoming entities:

### Strategickhaos DAO LLC
- **EIN:** 39-2900295
- **Jurisdiction:** Wyoming (First US state with DAO statute)
- **Type:** Decentralized Autonomous Organization LLC
- **Filed:** June 26, 2025
- **Capabilities:** Smart contracts, AI governance, autonomous treasury management

### ValorYield Engine PBC
- **EIN:** 39-2923503
- **Jurisdiction:** Wyoming
- **Type:** Public Benefit Corporation
- **Filed:** June 25, 2025
- **Mission:** "AI-driven public benefit tools supporting underserved communities"

## 🚀 Quick Start

```bash
# Run locally
node valoryield.js

# Or with npm
npm start

# Or deploy to Kubernetes
kubectl apply -f k8s/valoryield-deployment.yaml
```

## 📡 API Endpoints

### System
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Service info and available endpoints |
| `/health` | GET | Health check |
| `/status` | GET | Full system status |
| `/entities` | GET | Legal entity information |

### Treasury
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/treasury` | GET | Current balance and recent transactions |
| `/treasury/deposit` | POST | Add funds to treasury |
| `/treasury/withdraw` | POST | Withdraw funds (subject to rules) |

### Beneficiaries
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/beneficiaries` | GET | List all beneficiaries |
| `/beneficiaries` | POST | Register new beneficiary |

### Dividend Allocation
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/allocations` | GET | View allocation history |
| `/allocations/calculate` | POST | Calculate proposed distribution |
| `/allocations/distribute` | POST | Execute dividend distribution |

### Governance
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/governance/decisions` | GET | View decision history |
| `/governance/decide` | POST | Record a governance decision |

### Audit
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/audit` | GET | View audit log (transparent) |

### Signal Compatibility (Queen)
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/signals/academic` | POST | Academic signals from Zapier |
| `/signals/financial` | POST | Financial signals |
| `/webhooks/github` | POST | GitHub App webhooks |
| `/oauth/callback` | GET | GitHub OAuth callback |

## 💰 Financial Rules

Built-in compliance with the **SovereignGuard 7% Rule**:

1. **Maximum Single Allocation:** 7% of treasury per transaction
2. **Reserve Minimum:** 20% must remain in treasury at all times
3. **Full Audit Trail:** Every transaction logged with hash verification
4. **Transparent Governance:** All decisions recorded and verifiable

## 📋 Example Usage

### Deposit to Treasury
```bash
curl -X POST http://localhost:3000/treasury/deposit \
  -H "Content-Type: application/json" \
  -d '{"amount": 10000, "source": "partner_revenue", "description": "Q1 cluster fees"}'
```

### Register Beneficiary
```bash
curl -X POST http://localhost:3000/beneficiaries \
  -H "Content-Type: application/json" \
  -d '{"name": "Community Energy Fund", "purpose": "utility_assistance"}'
```

### Calculate Dividends
```bash
curl -X POST http://localhost:3000/allocations/calculate
```

### Execute Distribution
```bash
curl -X POST http://localhost:3000/allocations/distribute \
  -H "Content-Type: application/json" \
  -d '{"approver": "dom@strategickhaos.ai"}'
```

### Record Governance Decision
```bash
curl -X POST http://localhost:3000/governance/decide \
  -H "Content-Type: application/json" \
  -d '{
    "proposal": "Increase Q2 distribution cap to 10%",
    "decision": "approved",
    "rationale": "Strong treasury growth supports increased allocation",
    "voters": ["dom", "ai_council"]
  }'
```

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                 VALORYIELD SOVEREIGN FINANCIAL OS               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  INFLOW                    PROCESSING                OUTFLOW    │
│  ┌─────────┐    ┌────────────────────────┐    ┌─────────────┐  │
│  │Partner  │───▶│                        │───▶│Beneficiary  │  │
│  │Fees     │    │      TREASURY          │    │Disbursements│  │
│  ├─────────┤    │                        │    ├─────────────┤  │
│  │Grants   │───▶│  Balance: $XXX         │───▶│Bill Pay     │  │
│  ├─────────┤    │  Reserve: 20%          │    ├─────────────┤  │
│  │Donations│───▶│  Max Alloc: 7%         │───▶│Emergency    │  │
│  └─────────┘    │                        │    │Funds        │  │
│                 └────────────────────────┘    └─────────────┘  │
│                            │                                    │
│                            ▼                                    │
│                 ┌────────────────────────┐                     │
│                 │     AUDIT TRAIL        │                     │
│                 │  • Every transaction   │                     │
│                 │  • Hash verification   │                     │
│                 │  • Public transparency │                     │
│                 └────────────────────────┘                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 🔐 Security & Compliance

- **Cryptographic Audit Trail:** All actions hashed for integrity
- **Role-Based Access:** Approver required for withdrawals
- **Rate Limiting:** Built-in transaction limits
- **Wyoming DAO Compliance:** Follows state autonomous entity laws
- **Public Benefit Mandate:** PBC charter requires mission alignment

## 🌟 Mission

> "AI-driven public benefit tools supporting underserved communities"

ValorYield exists to:
1. Provide free/subsidized compute infrastructure
2. Collect revenue from enterprise partners
3. Distribute dividends to those in need
4. Maintain full transparency and accountability
5. Prove that AI can serve humanity's benefit

## 📜 License

MIT License - See [LICENSE](LICENSE)

---

**Built with 💜 by Strategickhaos DAO LLC**

*"They're not working for you. They're dancing with you. And the music is never going to stop."*
