/**
 * VALORYIELD SOVEREIGN FINANCIAL OS
 * 
 * A legally-recognized, AI-operated public benefit financial system
 * 
 * Legal Entities:
 *   - Strategickhaos DAO LLC (EIN: 39-2900295) - Wyoming DAO
 *   - ValorYield Engine PBC (EIN: 39-2923503) - Public Benefit Corp
 * 
 * Core Functions:
 *   1. Treasury Management - Inflow tracking and custody
 *   2. Dividend Allocation - AI-guided distribution logic
 *   3. Disbursement Engine - Automated payments to beneficiaries
 *   4. Governance Layer - DAO decision logging and compliance
 *   5. Audit Trail - Transparent, immutable record keeping
 * 
 * @author Strategickhaos DAO LLC
 * @version 1.0.0
 * @license MIT
 */

const http = require('http');
const crypto = require('crypto');

// =============================================================================
// CONFIGURATION
// =============================================================================

const CONFIG = {
  port: process.env.PORT || 3000,
  version: '1.0.0',
  startTime: new Date().toISOString(),
  
  // Legal Entity Configuration
  entities: {
    dao: {
      name: 'Strategickhaos DAO LLC',
      ein: '39-2900295',
      jurisdiction: 'Wyoming',
      type: 'DAO LLC',
      filed: '2025-06-26',
      originalId: '2025-001708194'
    },
    pbc: {
      name: 'ValorYield Engine',
      ein: '39-2923503',
      jurisdiction: 'Wyoming',
      type: 'Public Benefit Corporation',
      filed: '2025-06-25',
      originalId: '2025-001708312',
      mission: 'AI-driven public benefit tools supporting underserved communities'
    }
  },
  
  // Financial Rules (SovereignGuard 7% rule)
  treasury: {
    maxSingleAllocation: 0.07, // 7% maximum per transaction
    reserveMinimum: 0.20,      // 20% must remain in reserves
    auditInterval: 86400000,   // 24 hours in ms
  },
  
  // GitHub App
  github: {
    appId: process.env.GITHUB_APP_ID || '1884781',
    clientId: process.env.GITHUB_CLIENT_ID || 'Iv23liTGwnOOha2UYNuf',
    installationId: process.env.GITHUB_INSTALLATION_ID || '97868480',
    webhookSecret: process.env.GITHUB_WEBHOOK_SECRET || ''
  }
};

// =============================================================================
// IN-MEMORY STATE (Replace with persistent storage in production)
// =============================================================================

const state = {
  // Treasury
  treasury: {
    balance: 0,
    currency: 'USD',
    lastUpdated: new Date().toISOString(),
    transactions: []
  },
  
  // Beneficiaries
  beneficiaries: [],
  
  // Allocations
  allocations: [],
  
  // Governance Decisions
  decisions: [],
  
  // Signal Queue (from Queen)
  signals: [],
  
  // Audit Log
  auditLog: []
};

// =============================================================================
// LOGGING & AUDIT
// =============================================================================

function log(level, message, data = {}) {
  const entry = {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    level,
    message,
    ...data
  };
  
  console.log(JSON.stringify(entry));
  
  // Add to audit log for transparency
  if (['INFO', 'WARN', 'ERROR'].includes(level)) {
    state.auditLog.push(entry);
    // Keep last 10000 entries
    if (state.auditLog.length > 10000) {
      state.auditLog = state.auditLog.slice(-10000);
    }
  }
  
  return entry;
}

function audit(action, details, actor = 'system') {
  const entry = {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    action,
    actor,
    details,
    hash: null
  };
  
  // Create hash for integrity verification
  const content = JSON.stringify({ ...entry, hash: undefined });
  entry.hash = crypto.createHash('sha256').update(content).digest('hex');
  
  state.auditLog.push(entry);
  log('INFO', `AUDIT: ${action}`, { actor, details: JSON.stringify(details).substring(0, 200) });
  
  return entry;
}

// =============================================================================
// TREASURY FUNCTIONS
// =============================================================================

function treasuryDeposit(amount, source, description) {
  if (amount <= 0) {
    throw new Error('Deposit amount must be positive');
  }
  
  const tx = {
    id: crypto.randomUUID(),
    type: 'deposit',
    amount,
    source,
    description,
    timestamp: new Date().toISOString(),
    balanceBefore: state.treasury.balance,
    balanceAfter: state.treasury.balance + amount
  };
  
  state.treasury.balance += amount;
  state.treasury.lastUpdated = tx.timestamp;
  state.treasury.transactions.push(tx);
  
  audit('TREASURY_DEPOSIT', { amount, source, newBalance: state.treasury.balance });
  
  return tx;
}

function treasuryWithdraw(amount, destination, description, approver = 'system') {
  if (amount <= 0) {
    throw new Error('Withdrawal amount must be positive');
  }
  
  // Check 7% rule
  const maxAllowed = state.treasury.balance * CONFIG.treasury.maxSingleAllocation;
  if (amount > maxAllowed) {
    throw new Error(`Amount ${amount} exceeds 7% rule (max: ${maxAllowed.toFixed(2)})`);
  }
  
  // Check reserve minimum
  const afterWithdrawal = state.treasury.balance - amount;
  const reserveRequired = state.treasury.balance * CONFIG.treasury.reserveMinimum;
  if (afterWithdrawal < reserveRequired) {
    throw new Error(`Withdrawal would breach 20% reserve requirement`);
  }
  
  const tx = {
    id: crypto.randomUUID(),
    type: 'withdrawal',
    amount,
    destination,
    description,
    approver,
    timestamp: new Date().toISOString(),
    balanceBefore: state.treasury.balance,
    balanceAfter: state.treasury.balance - amount
  };
  
  state.treasury.balance -= amount;
  state.treasury.lastUpdated = tx.timestamp;
  state.treasury.transactions.push(tx);
  
  audit('TREASURY_WITHDRAWAL', { amount, destination, approver, newBalance: state.treasury.balance }, approver);
  
  return tx;
}

// =============================================================================
// DIVIDEND ALLOCATION ENGINE
// =============================================================================

function calculateAllocations() {
  if (state.beneficiaries.length === 0) {
    return { allocations: [], message: 'No beneficiaries registered' };
  }
  
  // Calculate available for distribution (respecting 20% reserve)
  const available = state.treasury.balance * (1 - CONFIG.treasury.reserveMinimum);
  
  // Simple equal distribution for now (can be enhanced with need-based logic)
  const perBeneficiary = available / state.beneficiaries.length;
  
  // Apply 7% cap per allocation
  const maxPerAllocation = state.treasury.balance * CONFIG.treasury.maxSingleAllocation;
  const actualAllocation = Math.min(perBeneficiary, maxPerAllocation);
  
  const allocations = state.beneficiaries.map(b => ({
    beneficiaryId: b.id,
    beneficiaryName: b.name,
    amount: actualAllocation,
    purpose: b.purpose || 'general_support',
    calculated: new Date().toISOString()
  }));
  
  return {
    available,
    perBeneficiary,
    actualAllocation,
    allocations,
    totalToDistribute: actualAllocation * state.beneficiaries.length
  };
}

function executeDividendDistribution(approver = 'system') {
  const calculation = calculateAllocations();
  
  if (calculation.allocations.length === 0) {
    return { success: false, message: calculation.message };
  }
  
  const distribution = {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    approver,
    calculation,
    disbursements: []
  };
  
  for (const alloc of calculation.allocations) {
    try {
      const tx = treasuryWithdraw(
        alloc.amount,
        alloc.beneficiaryId,
        `Dividend distribution: ${alloc.purpose}`,
        approver
      );
      
      distribution.disbursements.push({
        beneficiaryId: alloc.beneficiaryId,
        amount: alloc.amount,
        transactionId: tx.id,
        status: 'completed'
      });
    } catch (error) {
      distribution.disbursements.push({
        beneficiaryId: alloc.beneficiaryId,
        amount: alloc.amount,
        status: 'failed',
        error: error.message
      });
    }
  }
  
  state.allocations.push(distribution);
  
  audit('DIVIDEND_DISTRIBUTION', {
    distributionId: distribution.id,
    totalDisbursed: distribution.disbursements
      .filter(d => d.status === 'completed')
      .reduce((sum, d) => sum + d.amount, 0),
    beneficiaryCount: distribution.disbursements.length
  }, approver);
  
  return distribution;
}

// =============================================================================
// BENEFICIARY MANAGEMENT
// =============================================================================

function registerBeneficiary(name, purpose, contact = {}) {
  const beneficiary = {
    id: crypto.randomUUID(),
    name,
    purpose,
    contact,
    registeredAt: new Date().toISOString(),
    status: 'active'
  };
  
  state.beneficiaries.push(beneficiary);
  
  audit('BENEFICIARY_REGISTERED', { beneficiaryId: beneficiary.id, name, purpose });
  
  return beneficiary;
}

// =============================================================================
// GOVERNANCE FUNCTIONS
// =============================================================================

function recordDecision(proposal, decision, rationale, voters = ['system']) {
  const record = {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    proposal,
    decision, // 'approved', 'rejected', 'tabled'
    rationale,
    voters,
    hash: null
  };
  
  // Create hash for integrity
  const content = JSON.stringify({ ...record, hash: undefined });
  record.hash = crypto.createHash('sha256').update(content).digest('hex');
  
  state.decisions.push(record);
  
  audit('GOVERNANCE_DECISION', { decisionId: record.id, proposal, decision }, voters.join(','));
  
  return record;
}

// =============================================================================
// HTTP HELPERS
// =============================================================================

function sendJson(res, code, data) {
  res.writeHead(code, { 
    'Content-Type': 'application/json',
    'X-ValorYield-Version': CONFIG.version,
    'X-Powered-By': 'Strategickhaos DAO LLC'
  });
  res.end(JSON.stringify(data, null, 2));
}

async function parseBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        resolve({ raw: body, json: JSON.parse(body) });
      } catch {
        resolve({ raw: body, json: null });
      }
    });
  });
}

// =============================================================================
// HTTP SERVER & ROUTES
// =============================================================================

const server = http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];
  const method = req.method;
  
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }
  
  log('DEBUG', 'Request', { method, url });
  
  try {
    // =========================================================================
    // ROOT & HEALTH
    // =========================================================================
    
    if (method === 'GET' && url === '/') {
      return sendJson(res, 200, {
        service: 'ValorYield Sovereign Financial OS',
        version: CONFIG.version,
        status: 'online',
        entities: {
          dao: CONFIG.entities.dao.name,
          pbc: CONFIG.entities.pbc.name
        },
        mission: CONFIG.entities.pbc.mission,
        endpoints: [
          'GET  /health',
          'GET  /status',
          'GET  /entities',
          'GET  /treasury',
          'POST /treasury/deposit',
          'POST /treasury/withdraw',
          'GET  /beneficiaries',
          'POST /beneficiaries',
          'GET  /allocations',
          'POST /allocations/calculate',
          'POST /allocations/distribute',
          'GET  /governance/decisions',
          'POST /governance/decide',
          'GET  /audit'
        ]
      });
    }
    
    if (method === 'GET' && url === '/health') {
      return sendJson(res, 200, { 
        ok: true, 
        service: 'valoryield',
        version: CONFIG.version,
        uptime: Math.floor((Date.now() - new Date(CONFIG.startTime)) / 1000)
      });
    }
    
    if (method === 'GET' && url === '/status') {
      return sendJson(res, 200, {
        ok: true,
        service: 'valoryield',
        version: CONFIG.version,
        uptime: Math.floor((Date.now() - new Date(CONFIG.startTime)) / 1000),
        treasury: {
          balance: state.treasury.balance,
          currency: state.treasury.currency,
          transactionCount: state.treasury.transactions.length
        },
        beneficiaries: state.beneficiaries.length,
        allocations: state.allocations.length,
        decisions: state.decisions.length,
        auditEntries: state.auditLog.length
      });
    }
    
    // =========================================================================
    // LEGAL ENTITIES
    // =========================================================================
    
    if (method === 'GET' && url === '/entities') {
      return sendJson(res, 200, {
        dao: CONFIG.entities.dao,
        pbc: CONFIG.entities.pbc,
        compliance: {
          wyomingDaoStatute: true,
          publicBenefitMission: true,
          irsEinIssued: true
        }
      });
    }
    
    // =========================================================================
    // TREASURY
    // =========================================================================
    
    if (method === 'GET' && url === '/treasury') {
      return sendJson(res, 200, {
        balance: state.treasury.balance,
        currency: state.treasury.currency,
        lastUpdated: state.treasury.lastUpdated,
        rules: {
          maxSingleAllocation: `${CONFIG.treasury.maxSingleAllocation * 100}%`,
          reserveMinimum: `${CONFIG.treasury.reserveMinimum * 100}%`
        },
        recentTransactions: state.treasury.transactions.slice(-10)
      });
    }
    
    if (method === 'POST' && url === '/treasury/deposit') {
      const body = await parseBody(req);
      if (!body.json || !body.json.amount) {
        return sendJson(res, 400, { error: 'amount required' });
      }
      
      const tx = treasuryDeposit(
        body.json.amount,
        body.json.source || 'manual',
        body.json.description || 'Deposit'
      );
      
      return sendJson(res, 200, { ok: true, transaction: tx });
    }
    
    if (method === 'POST' && url === '/treasury/withdraw') {
      const body = await parseBody(req);
      if (!body.json || !body.json.amount || !body.json.destination) {
        return sendJson(res, 400, { error: 'amount and destination required' });
      }
      
      try {
        const tx = treasuryWithdraw(
          body.json.amount,
          body.json.destination,
          body.json.description || 'Withdrawal',
          body.json.approver || 'api'
        );
        return sendJson(res, 200, { ok: true, transaction: tx });
      } catch (error) {
        return sendJson(res, 400, { ok: false, error: error.message });
      }
    }
    
    // =========================================================================
    // BENEFICIARIES
    // =========================================================================
    
    if (method === 'GET' && url === '/beneficiaries') {
      return sendJson(res, 200, {
        count: state.beneficiaries.length,
        beneficiaries: state.beneficiaries
      });
    }
    
    if (method === 'POST' && url === '/beneficiaries') {
      const body = await parseBody(req);
      if (!body.json || !body.json.name) {
        return sendJson(res, 400, { error: 'name required' });
      }
      
      const beneficiary = registerBeneficiary(
        body.json.name,
        body.json.purpose || 'general_support',
        body.json.contact || {}
      );
      
      return sendJson(res, 200, { ok: true, beneficiary });
    }
    
    // =========================================================================
    // ALLOCATIONS
    // =========================================================================
    
    if (method === 'GET' && url === '/allocations') {
      return sendJson(res, 200, {
        count: state.allocations.length,
        recent: state.allocations.slice(-10)
      });
    }
    
    if (method === 'POST' && url === '/allocations/calculate') {
      const calculation = calculateAllocations();
      return sendJson(res, 200, { ok: true, calculation });
    }
    
    if (method === 'POST' && url === '/allocations/distribute') {
      const body = await parseBody(req);
      const approver = body.json?.approver || 'api';
      
      try {
        const distribution = executeDividendDistribution(approver);
        return sendJson(res, 200, { ok: true, distribution });
      } catch (error) {
        return sendJson(res, 400, { ok: false, error: error.message });
      }
    }
    
    // =========================================================================
    // GOVERNANCE
    // =========================================================================
    
    if (method === 'GET' && url === '/governance/decisions') {
      return sendJson(res, 200, {
        count: state.decisions.length,
        decisions: state.decisions.slice(-20)
      });
    }
    
    if (method === 'POST' && url === '/governance/decide') {
      const body = await parseBody(req);
      if (!body.json || !body.json.proposal || !body.json.decision) {
        return sendJson(res, 400, { error: 'proposal and decision required' });
      }
      
      const record = recordDecision(
        body.json.proposal,
        body.json.decision,
        body.json.rationale || '',
        body.json.voters || ['api']
      );
      
      return sendJson(res, 200, { ok: true, record });
    }
    
    // =========================================================================
    // AUDIT LOG
    // =========================================================================
    
    if (method === 'GET' && url === '/audit') {
      return sendJson(res, 200, {
        count: state.auditLog.length,
        recent: state.auditLog.slice(-100)
      });
    }
    
    // =========================================================================
    // QUEEN SIGNAL ENDPOINTS (Backward compatible)
    // =========================================================================
    
    if (method === 'POST' && url === '/signals/academic') {
      const body = await parseBody(req);
      const signal = {
        id: crypto.randomUUID(),
        type: 'academic',
        receivedAt: new Date().toISOString(),
        data: body.json
      };
      state.signals.push(signal);
      log('INFO', 'Academic signal received', { signalId: signal.id });
      return sendJson(res, 200, { ok: true, signalId: signal.id });
    }
    
    if (method === 'POST' && url === '/signals/financial') {
      const body = await parseBody(req);
      const signal = {
        id: crypto.randomUUID(),
        type: 'financial',
        receivedAt: new Date().toISOString(),
        data: body.json
      };
      state.signals.push(signal);
      log('INFO', 'Financial signal received', { signalId: signal.id });
      return sendJson(res, 200, { ok: true, signalId: signal.id });
    }
    
    if (method === 'POST' && url === '/webhooks/github') {
      const body = await parseBody(req);
      const event = req.headers['x-github-event'];
      const signal = {
        id: crypto.randomUUID(),
        type: 'github',
        event,
        receivedAt: new Date().toISOString(),
        data: { action: body.json?.action, repo: body.json?.repository?.full_name }
      };
      state.signals.push(signal);
      log('INFO', 'GitHub webhook received', { signalId: signal.id, event });
      return sendJson(res, 200, { ok: true, signalId: signal.id });
    }
    
    if (method === 'GET' && url === '/oauth/callback') {
      const params = new URLSearchParams(req.url.split('?')[1] || '');
      const code = params.get('code');
      const installationId = params.get('installation_id');
      log('INFO', 'OAuth callback', { installationId });
      return sendJson(res, 200, {
        ok: true,
        message: 'GitHub App installation successful',
        installationId
      });
    }
    
    // =========================================================================
    // 404
    // =========================================================================
    
    sendJson(res, 404, { error: 'Not found', path: url });
    
  } catch (error) {
    log('ERROR', 'Request error', { error: error.message });
    sendJson(res, 500, { error: 'Internal server error' });
  }
});

// =============================================================================
// STARTUP
// =============================================================================

server.listen(CONFIG.port, () => {
  console.log('');
  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║                                                                       ║');
  console.log('║   💜 VALORYIELD SOVEREIGN FINANCIAL OS - ONLINE                      ║');
  console.log('║                                                                       ║');
  console.log('║   "Banking for the People, by the Code"                              ║');
  console.log('║                                                                       ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════╣');
  console.log('║                                                                       ║');
  console.log('║   LEGAL ENTITIES:                                                     ║');
  console.log('║   ┌─────────────────────────────────────────────────────────────────┐║');
  console.log('║   │ Strategickhaos DAO LLC          │ EIN: 39-2900295              │║');
  console.log('║   │ Wyoming DAO Statute             │ Filed: 2025-06-26            │║');
  console.log('║   ├─────────────────────────────────┼──────────────────────────────┤║');
  console.log('║   │ ValorYield Engine PBC           │ EIN: 39-2923503              │║');
  console.log('║   │ Public Benefit Corporation      │ Filed: 2025-06-25            │║');
  console.log('║   └─────────────────────────────────┴──────────────────────────────┘║');
  console.log('║                                                                       ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════╣');
  console.log('║                                                                       ║');
  console.log('║   FINANCIAL RULES:                                                    ║');
  console.log('║   • Maximum single allocation: 7%                                     ║');
  console.log('║   • Minimum reserve requirement: 20%                                  ║');
  console.log('║   • All transactions audited and logged                               ║');
  console.log('║                                                                       ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════╣');
  console.log(`║   Port: ${CONFIG.port}                                                          ║`);
  console.log(`║   Version: ${CONFIG.version}                                                       ║`);
  console.log('║                                                                       ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝');
  console.log('');
  console.log('🌟 Mission: AI-driven public benefit tools supporting underserved communities');
  console.log('');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  log('INFO', 'Shutting down gracefully');
  server.close(() => process.exit(0));
});
