#!/bin/bash
# Strategickhaos DAO LLC - Azure Pipeline Migration + Trading Bot Integration
# Fixes macOS-13 retirement, adds webhook notification, integrates QET governance

set -e

REPO_PATH="${1:-.}"
PIPELINE_FILE="${REPO_PATH}/.azure-pipelines.yml"
ZAPIER_WEBHOOK_URL="${ZAPIER_WEBHOOK_URL:-https://hooks.zapier.com/hooks/catch/YOUR_HOOK_ID/}"
SLACK_CHANNEL="${SLACK_CHANNEL:-#trading-alerts}"

echo "🔧 Strategickhaos Pipeline Migration Tool"
echo "========================================="

# Step 1: Backup existing pipeline
if [ -f "$PIPELINE_FILE" ]; then
    cp "$PIPELINE_FILE" "${PIPELINE_FILE}.backup"
    echo "✅ Backed up existing pipeline to ${PIPELINE_FILE}.backup"
else
    echo "❌ Pipeline file not found: $PIPELINE_FILE"
    exit 1
fi

# Step 2: Migrate macOS-13 to macOS-14
echo "📝 Migrating macOS-13 → macOS-14..."
sed -i.bak \
    -e "s/vmImage: 'macOS-13'/vmImage: 'macOS-14'/g" \
    -e "s/vmImage: \"macOS-13\"/vmImage: \"macOS-14\"/g" \
    -e "s/vmImage: macOS-13/vmImage: macOS-14/g" \
    "$PIPELINE_FILE"

# Step 3: Add webhook notification stage if not present
if ! grep -q "WebhookNotification" "$PIPELINE_FILE"; then
    echo "🔗 Adding Zapier webhook notification stage..."
    
    cat >> "$PIPELINE_FILE" << 'EOF'

# Strategickhaos Trading Bot Webhook Integration
- stage: NotifyTradingSystem
  dependsOn: Build
  condition: succeeded()
  jobs:
    - job: WebhookNotification
      pool:
        vmImage: 'ubuntu-latest'
      steps:
        - task: Bash@3
          displayName: 'Notify Trading System'
          inputs:
            targetType: 'inline'
            script: |
              curl -X POST $ZAPIER_WEBHOOK_URL \
                -H "Content-Type: application/json" \
                -d "{
                  \"signal_type\": \"Pipeline Success\",
                  \"asset\": \"Azure DevOps CI/CD\",
                  \"repo\": \"$(Build.Repository.Name)\",
                  \"commit\": \"$(Build.SourceVersion)\",
                  \"pipeline\": \"$(Build.DefinitionName)\",
                  \"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",
                  \"status\": \"success\",
                  \"build_url\": \"$(System.TeamFoundationCollectionUri)$(System.TeamProject)/_build/results?buildId=$(Build.BuildId)\"
                }"
              
              echo "✅ Webhook notification sent to trading system"
EOF
fi

# Step 4: Add failure notification
if ! grep -q "NotifyFailure" "$PIPELINE_FILE"; then
    echo "🚨 Adding failure notification..."
    
    cat >> "$PIPELINE_FILE" << 'EOF'

- stage: NotifyFailure
  dependsOn: Build
  condition: failed()
  jobs:
    - job: NotifyFailure
      pool:
        vmImage: 'ubuntu-latest'
      steps:
        - task: Bash@3
          displayName: 'Notify Trading System of Failure'
          inputs:
            targetType: 'inline'
            script: |
              curl -X POST $ZAPIER_WEBHOOK_URL \
                -H "Content-Type: application/json" \
                -d "{
                  \"signal_type\": \"Pipeline Failure\",
                  \"asset\": \"Azure DevOps CI/CD\",
                  \"repo\": \"$(Build.Repository.Name)\",
                  \"commit\": \"$(Build.SourceVersion)\",
                  \"pipeline\": \"$(Build.DefinitionName)\",
                  \"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",
                  \"status\": \"failed\",
                  \"build_url\": \"$(System.TeamFoundationCollectionUri)$(System.TeamProject)/_build/results?buildId=$(Build.BuildId)\"
                }"
              
              echo "🚨 Failure notification sent to trading system"
EOF
fi

echo "✅ Pipeline migration complete"
echo ""
echo "📋 Changes made:"
echo "  - macOS-13 → macOS-14"
echo "  - Added Zapier webhook notification on success"
echo "  - Added Zapier webhook notification on failure"
echo ""
echo "Next steps:"
echo "1. Review the changes: git diff $PIPELINE_FILE"
echo "2. Commit: git add $PIPELINE_FILE && git commit -m 'Migrate to macOS-14, add trading webhook'"
echo "3. Push: git push"
echo "4. Watch it run: az pipelines run --name \"$(basename $REPO_PATH)\" --branch main"
echo ""
echo "🎯 Trading system will receive notifications at: $ZAPIER_WEBHOOK_URL"
