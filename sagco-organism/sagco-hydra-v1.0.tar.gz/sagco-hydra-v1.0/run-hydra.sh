#!/usr/bin/env bash
# run-hydra.sh — execute all organism heads in sequence
# Safe to run headless: no interactive prompts, all output to stdout

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"
mkdir -p logs

echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║   SAGCO ORGANISM v1.0 — HYDRA MODE                       ║"
echo "  ║   Dispatch: INPUT→lexer→parser→AST→router→subsystem→seal  ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""

# HEAD 1 — GPS magnetic fingerprint
echo "  ── HEAD 1: exchanger_locator (ML-ORGANISM-005) ──"
./exchanger_locator data/sample_readings.csv data/asset_fingerprints.json

# HEAD 2 — Insulation coverage
echo "  ── HEAD 2: field insulation (ML-ORGANISM-003) ──"
./sagco field insulation --csv data/insulation_survey_ca1648j.csv

# HEAD 3 — Pipe weld survey
echo "  ── HEAD 3: field pipe-survey ──"
./sagco field pipe-survey --csv data/pipe_survey_ca1648j.csv

# HEAD 4 — GPS bearing (node A → node B on CA-1648 J run)
echo "  ── HEAD 4: gps bearing ──"
./sagco gps bearing \
    --lat1 27.810164 --lon1 -97.593503 \
    --lat2 27.810203 --lon2 -97.593470

# Seal invocation log with SHA-256
echo "  ── SEAL: signing invocation log ──"
if command -v sha256sum &>/dev/null; then
    sha256sum logs/invocations.log 2>/dev/null && echo "  [SEALED]" || echo "  [LOG EMPTY — first run]"
fi

echo ""
echo "  SAGCO HYDRA COMPLETE"
echo ""
