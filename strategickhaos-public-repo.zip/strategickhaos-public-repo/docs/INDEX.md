# Documentation Index

## Strategickhaos DAO LLC — Documentation Registry

**Last Updated:** December 3, 2025  

---

## Quick Navigation

| Section | Description |
|---------|-------------|
| [Governance](#governance) | Trust, ethics, identity |
| [Architecture](#architecture) | Systems, infrastructure |
| [Legal](#legal) | Entities, compliance, IP |
| [Schemas](#schemas) | Machine-readable data |

---

## Governance

| Document | Path | Status |
|----------|------|--------|
| Trust Declaration | [`governance/TRUST_DECLARATION.md`](../governance/TRUST_DECLARATION.md) | v2.1.0 |
| Non-Aggression Clause | [`governance/NON_AGGRESSION_CLAUSE.md`](../governance/NON_AGGRESSION_CLAUSE.md) | **IMMUTABLE** |
| Public Identifiers | [`governance/public-identifier-registry.md`](../governance/public-identifier-registry.md) | v2.1.0 |

### Hierarchy

```
IMMUTABLE:
└── NON_AGGRESSION_CLAUSE.md

FOUNDATIONAL:
└── TRUST_DECLARATION.md

OPERATIONAL:
├── public-identifier-registry.md
└── schemas/*.json
```

---

## Architecture

| Document | Path | Description |
|----------|------|-------------|
| Executive Snapshot | [`docs/EXECUTIVE_SNAPSHOT.md`](EXECUTIVE_SNAPSHOT.md) | High-level overview |
| *Sovereignty Architecture* | Private | Compute philosophy |
| *K8s Topology* | Private | Cluster layout |

---

## Legal

| Entity | Type | Jurisdiction |
|--------|------|--------------|
| Strategickhaos DAO LLC | DAO LLC | Wyoming |
| ValorYield Engine | Nonprofit | Wyoming |
| *Others* | Various | See private registry |

### External Resources

- [DAO Compliance Repo](https://github.com/Strategickhaos/DAO_Compliance)
- [Wyoming SOS](https://wyobiz.wyo.gov)

---

## Schemas

| Schema | Path | Format |
|--------|------|--------|
| System Status | [`schemas/sovereign-empire-alert.json`](../schemas/sovereign-empire-alert.json) | JSON |
| Notebook Metadata | [`schemas/empire_notebook_metadata_corrected.yaml`](../schemas/empire_notebook_metadata_corrected.yaml) | YAML |

---

## Verification

```bash
# ORCID
https://orcid.org/0000-0005-2996-3526

# Wyoming SOS
https://wyobiz.wyo.gov

# GPG
keys.openpgp.org
```

---

*Part of Strategickhaos Sovereign Documentation*
