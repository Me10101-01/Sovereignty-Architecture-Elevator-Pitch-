#!/bin/bash
# =============================================================================
# Deploy Queen to GKE - jarvis-swarm-personal-001
# =============================================================================

set -e

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║   👑 DEPLOYING QUEEN TO GKE                                   ║"
echo "╚═══════════════════════════════════════════════════════════════╝"

# Configuration
PROJECT="jarvis-swarm-personal"
CLUSTER="jarvis-swarm-personal-001"
REGION="us-central1"

echo ""
echo "📍 Target: $CLUSTER in $PROJECT ($REGION)"
echo ""

# Step 1: Get credentials
echo "🔐 Getting cluster credentials..."
gcloud container clusters get-credentials $CLUSTER \
  --region $REGION \
  --project $PROJECT

# Step 2: Apply manifests
echo "📦 Applying Kubernetes manifests..."
kubectl apply -f queen-deployment.yaml

# Step 3: Wait for deployment
echo "⏳ Waiting for deployment to be ready..."
kubectl rollout status deployment/queen -n queen-system --timeout=120s

# Step 4: Get external IP
echo "🌐 Getting external IP..."
echo ""
echo "Waiting for LoadBalancer IP (this may take 1-2 minutes)..."

for i in {1..30}; do
  EXTERNAL_IP=$(kubectl get svc queen -n queen-system -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
  if [ -n "$EXTERNAL_IP" ]; then
    break
  fi
  echo "  Waiting... ($i/30)"
  sleep 5
done

echo ""
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║   ✅ QUEEN DEPLOYED SUCCESSFULLY                              ║"
echo "╠═══════════════════════════════════════════════════════════════╣"

if [ -n "$EXTERNAL_IP" ]; then
  echo "║   External IP: $EXTERNAL_IP"
  echo "║                                                               ║"
  echo "║   Test endpoints:                                             ║"
  echo "║     curl http://$EXTERNAL_IP/health"
  echo "║     curl http://$EXTERNAL_IP/status"
  echo "║                                                               ║"
  echo "║   DNS Configuration:                                          ║"
  echo "║     Point queen.strategickhaos.ai → $EXTERNAL_IP"
  echo "╚═══════════════════════════════════════════════════════════════╝"
else
  echo "║   LoadBalancer IP pending...                                  ║"
  echo "║   Run: kubectl get svc queen -n queen-system                  ║"
  echo "╚═══════════════════════════════════════════════════════════════╝"
fi

echo ""
echo "🎯 Next steps:"
echo "   1. Wait for external IP if not shown above"
echo "   2. Add DNS record: queen.strategickhaos.ai → \$EXTERNAL_IP"
echo "   3. Update GitHub App webhook URL"
echo "   4. Test: curl https://queen.strategickhaos.ai/health"
echo ""
