SAGCO ORGANISM v1.0.0
=====================
Self-contained cognition stack. No internet. No API keys. No external models.

INSTALL:
  tar -xzf sagco-organism-v1.0.0.tar.gz
  cd sagco-organism
  sh install.sh

COMMANDS:
  sagco help
  sagco priority [N]              — rank organs by weight
  sagco organ <name>              — inspect a single organ
  sagco subsystem <organ>         — dependency graph
  sagco blueprint                 — full organism summary
  sagco recover                   — forensic ERU rebuild
  sagco status                    — health check

POINT TO YOUR TREE:
  export SAGCO_TREE=/path/to/sagco_first_party_tree.json
  sagco blueprint

iOS (a-Shell):
  Same commands. Set SAGCO_BIN=~/Documents/bin in install.sh first.

No LLM required. The organism reads its own memory.
