#!/bin/sh
# SAGCO Organism Installer — no internet, no API keys, no external models.
# Works on Alpine Linux, iOS a-Shell, Raspberry Pi, any Python 3 system.

INSTALL_DIR="${SAGCO_INSTALL:-/root}"
BIN_DIR="${SAGCO_BIN:-/usr/local/bin}"
WORK_DIR="$INSTALL_DIR/sagco_workspace"

echo "SAGCO ORGANISM INSTALLER"
echo "========================"
echo "workspace : $WORK_DIR"
echo "bin       : $BIN_DIR"
echo ""

# Create workspace
mkdir -p "$WORK_DIR"
mkdir -p "$BIN_DIR"

# Copy tools
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
for f in sagco_priority.py sagco_subsystem_graph.py sagco_blueprint.py sagco_eru_recover.py; do
    if [ -f "$SCRIPT_DIR/$f" ]; then
        cp "$SCRIPT_DIR/$f" "$WORK_DIR/$f"
        echo "  installed: $f"
    fi
done

# Wire the dispatcher
cp "$SCRIPT_DIR/sagco-dispatcher" "$BIN_DIR/sagco"
chmod +x "$BIN_DIR/sagco"
echo "  installed: sagco → $BIN_DIR/sagco"

# Fix PATH in profile if needed
if ! echo "$PATH" | grep -q "$BIN_DIR"; then
    echo "export PATH=\"$BIN_DIR:\$PATH\"" >> "$INSTALL_DIR/.profile"
    echo "  added $BIN_DIR to PATH in .profile"
fi

echo ""
echo "DONE. Run:"
echo "  export PATH=\"$BIN_DIR:\$PATH\""
echo "  sagco help"
