# PUBLIC IDENTIFIER REGISTRY

## Strategickhaos DAO LLC — Verified Identity & Credential Bundle

**Document ID:** PUB-ID-2025-001  
**Effective Date:** June 25, 2025  
**Last Updated:** December 3, 2025  
**Version:** 2.0.0  
**Verification Status:** ✅ VERIFIED  

---

## Section 1: Legal Entity Identification

### 1.1 — Primary Entity
| Field | Value |
|-------|-------|
| **Legal Name** | Strategickhaos DAO LLC |
| **Entity Type** | Decentralized Autonomous Organization LLC |
| **Jurisdiction** | State of Wyoming, United States |
| **Governing Statute** | Wyoming Statutes §17-31-101 et seq. |
| **Filing Date** | June 25, 2025 at 2:08 PM |
| **Entity ID** | 2025-001708194 |
| **EIN** | 39-2900295 |
| **Effective Date** | July 4, 2025 |
| **Duration** | Perpetual |
| **Status** | ✅ Active, Good Standing |
| **DBA** | ValorYield Engine |
| **Registered Agent** | Northwest Registered Agent LLC |
| **Agent Address** | 30 N Gould St Ste N, Sheridan, WY 82801 |
| **Principal Address** | 1216 S Fredonia St, Longview, TX 75602 |

### 1.2 — Affiliated Entities

#### ValorYield Engine (Public Benefit Nonprofit)
| Field | Value |
|-------|-------|
| **Entity Type** | Wyoming Public Benefit Nonprofit Corporation |
| **Filing Date** | June 25, 2025 at 3:49 PM |
| **Entity ID** | 2025-001708312 |
| **EIN** | 39-2923503 |
| **Has Members** | No |
| **Status** | ✅ Active |
| **501(c)(3) Status** | Pending (Form 1023/1023-EZ required) |
| **Mission** | AI-driven dividend allocation for veteran housing/vehicle expenses |

#### Skyline Strategies Rope Access & Rescue Production LLC
| Field | Value |
|-------|-------|
| **Entity Type** | Louisiana LLC |
| **Filing Date** | May 7, 2024 |
| **EIN** | 99-2899134 |
| **Address** | 702 E School St Ste B103, Lake Charles, LA 70607 |
| **Status** | ✅ Active |

#### Garza's Happy Healthy Organic Greens and More LLC
| Field | Value |
|-------|-------|
| **Entity Type** | Texas LLC |
| **Filing Date** | December 2, 2022 |
| **State File #** | 804827477 |
| **Document #** | 1202609460002 |
| **EIN** | 92-1288715 |
| **Address** | 440 Louisiana St Ste 900, Houston, TX 77002 |
| **Registered Agent** | 1060 Clarence Dr Suite 250, Frisco, TX 75033 |
| **Status** | ✅ Active |

---

## Section 2: Founder Identification

### 2.1 — Personal Identity
| Field | Value |
|-------|-------|
| **Full Legal Name** | Domenic Gabriel Garza |
| **Role** | Sole Organizer, Managing Member, Core Architect |
| **ORCID** | [0000-0005-2996-3526](https://orcid.org/0000-0005-2996-3526) |
| **GitHub (Personal)** | [@Strategickhaos](https://github.com/Strategickhaos), [@Me10101-01](https://github.com/Me10101-01) |

### 2.2 — Education Credentials
| Institution | Program | Status | Student ID |
|-------------|---------|--------|------------|
| Southern New Hampshire University | BS Computer Science + Cybersecurity (Dual Major), Software Engineering Concentration | Active, 45/120 credits, GPA 3.732 | 3413281 |
| San Jacinto College | Previous enrollment | Verify status | garza.d678936@stu.sanjac.edu |

---

## Section 3: Smart Contract & Blockchain Identity

### 3.1 — Smart Contracts
| Contract | Description | Location |
|----------|-------------|----------|
| **StrategickhaosUIDP.sol** | UIDP-based governance and NFT licensing | [GitHub](https://github.com/Strategickhaos/DAO_Compliance/blob/main/contracts/StrategickhaosUIDP.sol) |
| **Deployed Address** | Pending deployment to Ethereum mainnet | TBD |

### 3.2 — Wyoming Utility Token (Pending Verification)
| Field | Value |
|-------|-------|
| **Statute Reference** | W.S. §34-29-106 (Digital Asset Exemption) |
| **Additional Reference** | W.S. §17-4-206 (Utility Token) |
| **Filing Status** | Notice of Intent filed (verify with WY SOS) |
| **Contact** | 307-777-7370 |

### 3.3 — Public Notarization & IPFS
| Resource | Link |
|----------|------|
| **IPFS Announcement** | [GitHub](https://github.com/Strategickhaos/DAO_Compliance/blob/main/docs/contracts/uidp/STRATEGICKHAOS_UIDP_IPFS_ANNOUNCEMENT.txt) |
| **NFT License Hash** | [GitHub](https://github.com/Strategickhaos/DAO_Compliance/blob/main/docs/contracts/uidp/hashes/UIDP_NFT_LICENSES.md.sha256) |

---

## Section 4: Platform Identities

### 4.1 — AI Platforms
| Platform | Account Type | Workspace(s) | Status |
|----------|--------------|--------------|--------|
| **Claude (Anthropic)** | SNHU .edu account | "domenic.garza@snhu.edu's Organization", "Legends Of Minds OS" | ✅ Active |
| **Claude (Anthropic)** | Personal account | "Strategickhaos" | ✅ Active |
| **GPT (OpenAI)** | Pro subscription | Custom assistants: "Baby", "Legion Node Advisor" | ✅ Active |
| **Grok (xAI)** | Personal | — | ✅ Active |

### 4.2 — Developer Platforms
| Platform | Identity | Type | Status |
|----------|----------|------|--------|
| **GitHub Enterprise** | Strategickhaos Swarm Intelligence | Organization | ✅ Active |
| **GitHub App** | StrategickhaosControlAI | Integration | ✅ Active |
| **Azure DevOps** | at-strategickhaos | Organization (Owner) | ✅ Active until 12/29/2025 |
| **Bugcrowd** | [Strategickhaos](https://bugcrowd.com/h/Strategickhaos) | Security Researcher | ✅ Active |
| **Ngrok** | Personal License | Invoice UTNCEV-00003 | ✅ Paid |

### 4.3 — Academic & Research
| Platform | Identity | Status |
|----------|----------|--------|
| **ORCID** | [0000-0005-2996-3526](https://orcid.org/0000-0005-2996-3526) | ✅ Verified |
| **UIDP.org** | Community Partner | ✅ Registered |

---

## Section 5: Infrastructure Identifiers

### 5.1 — Google Cloud Platform
| Resource | Project ID | Project Number | Status |
|----------|------------|----------------|--------|
| **My First Project** | central-achy-463919-r1 | 331015150353 | Active |
| **Jarvis Swarm Personal** | jarvis-swarm-personal | 451173083E | Active |

### 5.2 — GKE Clusters
| Cluster | Region | Mode | Endpoint IP | Role |
|---------|--------|------|-------------|------|
| jarvis-swarm-personal-001 | us-central1 | Autopilot | 34.89.88.27 | Primary Swarm |
| autopilot-cluster-1 | us-central1 | Autopilot | 35.192.28.199 | Red Team |

### 5.3 — Domain Registry
| Domain | Status | DNS |
|--------|--------|-----|
| strategickhaos.com | ✅ Owned | Active |
| swarm.strategickhaos.com | Pending | Requires A record → ingress LB |

---

## Section 6: Cryptographic Identities

### 6.1 — GPG Key
| Field | Value |
|-------|-------|
| **Key Server** | keys.openpgp.org |
| **Fingerprint** | `CEB E55 C8FA 7880 E19769 B0B CB3464 7214 E15F9` |
| **Full (reconstructed)** | `CEBE55C8FA7880E19769B0BCB34647214E15F9` |

### 6.2 — Device Identifiers (Reference Only)
| Device | Local IP | MAC (partial) |
|--------|----------|---------------|
| Domenics-iPad | 192.168.1.131 | 0E:31:E4:DA:CB:2A:B |

---

## Section 7: Legal & Governance Documents

### 7.1 — Repository Structure
**Primary Compliance Repository:** [github.com/Strategickhaos/DAO_Compliance](https://github.com/Strategickhaos/DAO_Compliance)

| Document | Path |
|----------|------|
| DAO Constitution | `/legal/constitution/Strategickhaos_DAO_Constitution.md` |
| UIDP License Terms | `/legal/uidp/UIDP_Terms_License.md` |
| EIN Registry | `/legal/ein/EIN_registry.txt` |
| Stripe/PayPal Compliance | `/docs/contracts/uidp/compliance/stripe_checkout/` |
| Notarization Workflow | `/.github/workflows/notarize.yml` |

### 7.2 — Governance Documents (This Bundle)
| Document | Purpose |
|----------|---------|
| `TRUST_DECLARATION.md` | Foundational trust instrument |
| `NON_AGGRESSION_CLAUSE.md` | Immutable ethical constraints |
| `public-identifier-registry.md` | This document |
| `Sovereign_Empire_Alert.json` | System status/alerts |

---

## Section 8: Verification Instructions

### 8.1 — For Humans
1. Visit Wyoming Secretary of State: [wyobiz.wyo.gov](https://wyobiz.wyo.gov)
2. Search Entity ID: `2025-001708194` (DAO) or `2025-001708312` (Nonprofit)
3. Verify ORCID: [orcid.org/0000-0005-2996-3526](https://orcid.org/0000-0005-2996-3526)
4. Check GitHub: [github.com/Strategickhaos](https://github.com/Strategickhaos)

### 8.2 — For AI Auditors
```bash
# Verify GPG signature
gpg --keyserver keys.openpgp.org --recv-keys [KEY_ID]
gpg --verify [DOCUMENT].sig [DOCUMENT]

# Verify OpenTimestamps
ots verify [DOCUMENT].ots

# Verify file integrity
blake3 [DOCUMENT] | grep [EXPECTED_HASH]

# Verify GitHub artifacts
curl -H "Accept: application/vnd.github.v3+json" \
  https://api.github.com/repos/Strategickhaos/DAO_Compliance/commits
```

### 8.3 — Emergency Contact
| Purpose | Contact |
|---------|---------|
| Security Issues | security@strategickhaos.ai |
| Legal Inquiries | Via registered agent |
| Wyoming SOS | 307-777-7370 |

---

## Document Integrity

```
SHA256: [TO BE COMPUTED ON FINAL VERSION]
BLAKE3: [TO BE COMPUTED ON FINAL VERSION]
OTS:    [TO BE ANCHORED]
```

**Last Verification:** December 3, 2025  
**Next Scheduled Audit:** January 3, 2026  

---

*This document is the canonical public identity reference for Strategickhaos DAO LLC. All claims are verifiable through the methods described in Section 8.*
