/**
 * QUEEN.JS - Estrategi-Khaos Queen Orchestrator
 * 
 * Central signal router for Strategickhaos Sovereign Infrastructure
 * 
 * Endpoints:
 *   POST /signals/academic    - Receives SNHU/academic email signals from Zapier
 *   POST /signals/financial   - Receives financial signals (Thread Bank, etc.)
 *   POST /signals/security    - Receives security alerts
 *   POST /webhooks/github     - Receives GitHub App webhooks
 *   GET  /health              - Health check endpoint
 *   GET  /status              - Full system status
 * 
 * Environment Variables:
 *   PORT                    - Server port (default: 3000)
 *   GITHUB_APP_ID           - GitHub App ID (1884781)
 *   GITHUB_WEBHOOK_SECRET   - Secret for validating GitHub webhooks
 *   ZAPIER_WEBHOOK_SECRET   - Optional secret for Zapier validation
 *   NATS_URL                - NATS server URL for event publishing
 *   DISCORD_WEBHOOK_URL     - Discord webhook for notifications
 * 
 * @author Strategickhaos DAO LLC
 * @version 1.0.0
 * @license Proprietary
 */

const http = require('http');
const crypto = require('crypto');

// =============================================================================
// CONFIGURATION
// =============================================================================

const CONFIG = {
  port: process.env.PORT || 3000,
  githubAppId: process.env.GITHUB_APP_ID || '1884781',
  githubWebhookSecret: process.env.GITHUB_WEBHOOK_SECRET || '',
  zapierWebhookSecret: process.env.ZAPIER_WEBHOOK_SECRET || '',
  natsUrl: process.env.NATS_URL || '',
  discordWebhookUrl: process.env.DISCORD_WEBHOOK_URL || '',
  version: '1.0.0',
  startTime: new Date().toISOString()
};

// =============================================================================
// LOGGING
// =============================================================================

const LOG_LEVELS = { DEBUG: 0, INFO: 1, WARN: 2, ERROR: 3 };
const currentLogLevel = LOG_LEVELS.DEBUG;

function log(level, message, data = {}) {
  if (LOG_LEVELS[level] >= currentLogLevel) {
    const entry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      ...data
    };
    console.log(JSON.stringify(entry));
  }
}

// =============================================================================
// SIGNAL QUEUE (In-memory for now, will connect to NATS later)
// =============================================================================

const signalQueue = [];
const MAX_QUEUE_SIZE = 1000;

function enqueueSignal(signal) {
  signalQueue.push({
    id: crypto.randomUUID(),
    receivedAt: new Date().toISOString(),
    ...signal
  });
  
  // Trim queue if too large
  if (signalQueue.length > MAX_QUEUE_SIZE) {
    signalQueue.shift();
  }
  
  log('INFO', 'Signal enqueued', { type: signal.type, queueSize: signalQueue.length });
  
  // TODO: Publish to NATS when configured
  // publishToNats(signal);
  
  return signalQueue[signalQueue.length - 1];
}

// =============================================================================
// WEBHOOK SIGNATURE VERIFICATION
// =============================================================================

function verifyGitHubSignature(payload, signature) {
  if (!CONFIG.githubWebhookSecret) {
    log('WARN', 'GitHub webhook secret not configured, skipping verification');
    return true;
  }
  
  const hmac = crypto.createHmac('sha256', CONFIG.githubWebhookSecret);
  const digest = 'sha256=' + hmac.update(payload).digest('hex');
  
  try {
    return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(signature || ''));
  } catch {
    return false;
  }
}

function verifyZapierSignature(payload, signature) {
  if (!CONFIG.zapierWebhookSecret) {
    // No secret configured, allow all (but log warning)
    log('DEBUG', 'Zapier webhook secret not configured, allowing request');
    return true;
  }
  
  const hmac = crypto.createHmac('sha256', CONFIG.zapierWebhookSecret);
  const digest = hmac.update(payload).digest('hex');
  
  try {
    return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(signature || ''));
  } catch {
    return false;
  }
}

// =============================================================================
// REQUEST PARSING
// =============================================================================

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      try {
        resolve({ raw: body, json: body ? JSON.parse(body) : {} });
      } catch (e) {
        resolve({ raw: body, json: null, error: e.message });
      }
    });
    req.on('error', reject);
  });
}

function parseUrl(url) {
  const [path, queryString] = url.split('?');
  const query = {};
  if (queryString) {
    queryString.split('&').forEach(pair => {
      const [key, value] = pair.split('=');
      query[decodeURIComponent(key)] = decodeURIComponent(value || '');
    });
  }
  return { path, query };
}

// =============================================================================
// RESPONSE HELPERS
// =============================================================================

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, { 
    'Content-Type': 'application/json',
    'X-Queen-Version': CONFIG.version
  });
  res.end(JSON.stringify(data));
}

function sendError(res, statusCode, message, details = {}) {
  log('ERROR', message, details);
  sendJson(res, statusCode, { ok: false, error: message, ...details });
}

// =============================================================================
// ROUTE HANDLERS
// =============================================================================

// Health check
function handleHealth(req, res) {
  sendJson(res, 200, {
    ok: true,
    service: 'queen',
    version: CONFIG.version,
    uptime: Math.floor((Date.now() - new Date(CONFIG.startTime).getTime()) / 1000),
    startTime: CONFIG.startTime
  });
}

// Full status
function handleStatus(req, res) {
  sendJson(res, 200, {
    ok: true,
    service: 'queen',
    version: CONFIG.version,
    uptime: Math.floor((Date.now() - new Date(CONFIG.startTime).getTime()) / 1000),
    startTime: CONFIG.startTime,
    config: {
      githubAppId: CONFIG.githubAppId,
      githubWebhookSecretConfigured: !!CONFIG.githubWebhookSecret,
      zapierWebhookSecretConfigured: !!CONFIG.zapierWebhookSecret,
      natsConfigured: !!CONFIG.natsUrl,
      discordConfigured: !!CONFIG.discordWebhookUrl
    },
    queue: {
      size: signalQueue.length,
      maxSize: MAX_QUEUE_SIZE
    },
    recentSignals: signalQueue.slice(-10).map(s => ({
      id: s.id,
      type: s.type,
      receivedAt: s.receivedAt
    }))
  });
}

// Academic signals (from Zapier - SNHU emails, etc.)
async function handleAcademicSignal(req, res, body) {
  log('INFO', 'Received academic signal', { 
    contentLength: body.raw.length,
    hasJson: !!body.json
  });
  
  // Verify Zapier signature if configured
  const signature = req.headers['x-zapier-signature'] || req.headers['x-hook-secret'];
  if (!verifyZapierSignature(body.raw, signature)) {
    return sendError(res, 401, 'Invalid signature');
  }
  
  if (!body.json) {
    return sendError(res, 400, 'Invalid JSON body');
  }
  
  // Extract email data from Zapier payload
  const email = body.json;
  
  const signal = enqueueSignal({
    type: 'academic',
    source: 'zapier',
    data: {
      subject: email.Subject || email.subject || 'No Subject',
      from: email['From Email Address Address'] || email.from || 'Unknown',
      to: email['To Recipients Email Address Address'] || email.to || 'Unknown',
      receivedAt: email['Received Date Time'] || email.receivedAt || new Date().toISOString(),
      bodyPreview: (email['Body Preview'] || email.bodyPreview || '').substring(0, 500),
      importance: email.Importance || email.importance || 'normal',
      hasAttachments: email['Has Attachments'] === 'true' || email.hasAttachments || false,
      messageId: email['Internet Message Id'] || email.messageId || null,
      // Classification
      isSnhu: (email['From Email Address Address'] || '').includes('snhu.edu'),
      classification: classifyAcademicEmail(email)
    }
  });
  
  log('INFO', 'Academic signal processed', { 
    signalId: signal.id,
    subject: signal.data.subject,
    isSnhu: signal.data.isSnhu,
    classification: signal.data.classification
  });
  
  // TODO: Forward to appropriate handler based on classification
  // - Assignment due → Calendar integration
  // - Grade posted → Dashboard update
  // - Instructor message → Priority notification
  
  sendJson(res, 200, { 
    ok: true, 
    signalId: signal.id,
    classification: signal.data.classification,
    message: 'Academic signal received and queued'
  });
}

// Classify academic emails
function classifyAcademicEmail(email) {
  const subject = (email.Subject || email.subject || '').toLowerCase();
  const body = (email['Body Preview'] || email.bodyPreview || '').toLowerCase();
  const from = (email['From Email Address Address'] || email.from || '').toLowerCase();
  
  // SNHU-specific patterns
  if (subject.includes('grade') || body.includes('grade posted')) {
    return 'grade_notification';
  }
  if (subject.includes('assignment') || subject.includes('due')) {
    return 'assignment_reminder';
  }
  if (subject.includes('announcement') || from.includes('brightspace')) {
    return 'course_announcement';
  }
  if (subject.includes('discussion') || body.includes('discussion board')) {
    return 'discussion_notification';
  }
  if (from.includes('advisor') || from.includes('academic')) {
    return 'advisor_message';
  }
  if (from.includes('snhu.edu')) {
    return 'snhu_general';
  }
  
  return 'unclassified';
}

// Financial signals
async function handleFinancialSignal(req, res, body) {
  log('INFO', 'Received financial signal', { contentLength: body.raw.length });
  
  if (!body.json) {
    return sendError(res, 400, 'Invalid JSON body');
  }
  
  const signal = enqueueSignal({
    type: 'financial',
    source: body.json.source || 'unknown',
    data: body.json
  });
  
  // Financial signals get extra logging
  log('WARN', 'Financial signal received - requires review', {
    signalId: signal.id,
    source: signal.source
  });
  
  sendJson(res, 200, { 
    ok: true, 
    signalId: signal.id,
    message: 'Financial signal received - queued for review'
  });
}

// Security signals
async function handleSecuritySignal(req, res, body) {
  log('WARN', 'Received security signal', { contentLength: body.raw.length });
  
  if (!body.json) {
    return sendError(res, 400, 'Invalid JSON body');
  }
  
  const signal = enqueueSignal({
    type: 'security',
    source: body.json.source || 'unknown',
    severity: body.json.severity || 'medium',
    data: body.json
  });
  
  // Security signals always log at WARN or higher
  log('WARN', 'Security signal processed', {
    signalId: signal.id,
    severity: signal.severity
  });
  
  // TODO: If severity is HIGH or CRITICAL, send Discord notification immediately
  
  sendJson(res, 200, { 
    ok: true, 
    signalId: signal.id,
    message: 'Security signal received and logged'
  });
}

// GitHub webhooks
async function handleGitHubWebhook(req, res, body) {
  const event = req.headers['x-github-event'];
  const delivery = req.headers['x-github-delivery'];
  const signature = req.headers['x-hub-signature-256'];
  
  log('INFO', 'Received GitHub webhook', { event, delivery });
  
  // Verify signature
  if (!verifyGitHubSignature(body.raw, signature)) {
    return sendError(res, 401, 'Invalid GitHub signature');
  }
  
  if (!body.json) {
    return sendError(res, 400, 'Invalid JSON body');
  }
  
  const signal = enqueueSignal({
    type: 'github',
    event: event,
    delivery: delivery,
    data: {
      action: body.json.action,
      repository: body.json.repository?.full_name,
      sender: body.json.sender?.login,
      // Don't store full payload, just key fields
    }
  });
  
  log('INFO', 'GitHub webhook processed', {
    signalId: signal.id,
    event: event,
    action: body.json.action,
    repo: body.json.repository?.full_name
  });
  
  sendJson(res, 200, { 
    ok: true, 
    signalId: signal.id,
    message: `GitHub ${event} event received`
  });
}

// =============================================================================
// ROUTER
// =============================================================================

async function router(req, res) {
  const { path } = parseUrl(req.url);
  const method = req.method;
  
  log('DEBUG', 'Request received', { method, path });
  
  // CORS headers for Zapier
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Zapier-Signature, X-Hook-Secret');
  
  // Handle preflight
  if (method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }
  
  // Parse body for POST requests
  let body = { raw: '', json: {} };
  if (method === 'POST') {
    body = await parseBody(req);
  }
  
  // Route
  try {
    switch (true) {
      // Health & Status
      case method === 'GET' && path === '/health':
        return handleHealth(req, res);
      
      case method === 'GET' && path === '/status':
        return handleStatus(req, res);
      
      case method === 'GET' && path === '/':
        return sendJson(res, 200, { 
          ok: true, 
          service: 'Estrategi-Khaos Queen',
          version: CONFIG.version,
          endpoints: [
            'GET  /health',
            'GET  /status', 
            'POST /signals/academic',
            'POST /signals/financial',
            'POST /signals/security',
            'POST /webhooks/github'
          ]
        });
      
      // Signals
      case method === 'POST' && path === '/signals/academic':
        return await handleAcademicSignal(req, res, body);
      
      case method === 'POST' && path === '/signals/financial':
        return await handleFinancialSignal(req, res, body);
      
      case method === 'POST' && path === '/signals/security':
        return await handleSecuritySignal(req, res, body);
      
      // Webhooks
      case method === 'POST' && path === '/webhooks/github':
        return await handleGitHubWebhook(req, res, body);
      
      // 404
      default:
        return sendError(res, 404, 'Not found', { path, method });
    }
  } catch (error) {
    log('ERROR', 'Request handler error', { error: error.message, stack: error.stack });
    return sendError(res, 500, 'Internal server error');
  }
}

// =============================================================================
// SERVER
// =============================================================================

const server = http.createServer(router);

server.listen(CONFIG.port, () => {
  console.log('');
  console.log('╔═══════════════════════════════════════════════════════════════╗');
  console.log('║                                                               ║');
  console.log('║   👑 ESTRATEGI-KHAOS QUEEN - ONLINE                          ║');
  console.log('║                                                               ║');
  console.log('║   Strategickhaos Sovereign Infrastructure Orchestrator       ║');
  console.log('║                                                               ║');
  console.log('╠═══════════════════════════════════════════════════════════════╣');
  console.log(`║   Port:     ${CONFIG.port.toString().padEnd(47)}║`);
  console.log(`║   Version:  ${CONFIG.version.padEnd(47)}║`);
  console.log(`║   Started:  ${CONFIG.startTime.padEnd(47)}║`);
  console.log('╠═══════════════════════════════════════════════════════════════╣');
  console.log('║   Endpoints:                                                  ║');
  console.log('║     GET  /health           - Health check                     ║');
  console.log('║     GET  /status           - Full status                      ║');
  console.log('║     POST /signals/academic - Academic emails (Zapier)         ║');
  console.log('║     POST /signals/financial- Financial signals                ║');
  console.log('║     POST /signals/security - Security alerts                  ║');
  console.log('║     POST /webhooks/github  - GitHub App webhooks              ║');
  console.log('╠═══════════════════════════════════════════════════════════════╣');
  console.log('║   Config:                                                     ║');
  console.log(`║     GitHub App ID:      ${CONFIG.githubAppId.padEnd(36)}║`);
  console.log(`║     Webhook Secret:     ${(CONFIG.githubWebhookSecret ? '✓ Configured' : '✗ Not set').padEnd(36)}║`);
  console.log(`║     Zapier Secret:      ${(CONFIG.zapierWebhookSecret ? '✓ Configured' : '✗ Not set').padEnd(36)}║`);
  console.log(`║     NATS URL:           ${(CONFIG.natsUrl ? '✓ Configured' : '✗ Not set').padEnd(36)}║`);
  console.log(`║     Discord Webhook:    ${(CONFIG.discordWebhookUrl ? '✓ Configured' : '✗ Not set').padEnd(36)}║`);
  console.log('║                                                               ║');
  console.log('╚═══════════════════════════════════════════════════════════════╝');
  console.log('');
  console.log('🐝 The Queen awaits her signals...');
  console.log('');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  log('INFO', 'Received SIGTERM, shutting down gracefully');
  server.close(() => {
    log('INFO', 'Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  log('INFO', 'Received SIGINT, shutting down gracefully');
  server.close(() => {
    log('INFO', 'Server closed');
    process.exit(0);
  });
});
