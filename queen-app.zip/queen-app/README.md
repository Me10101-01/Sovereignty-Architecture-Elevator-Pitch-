# 👑 Estrategi-Khaos Queen

**Central Signal Orchestrator for Strategickhaos Sovereign Infrastructure**

## Quick Start (Codespaces)

```bash
# 1. Clone or create codespace
# 2. Run:
node queen.js

# 3. Make port 3000 public in Codespaces
# 4. Copy your URL: https://YOUR-CODESPACE-NAME.github.dev
```

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Service info |
| GET | `/health` | Health check |
| GET | `/status` | Full status + recent signals |
| POST | `/signals/academic` | Academic emails from Zapier |
| POST | `/signals/financial` | Financial signals |
| POST | `/signals/security` | Security alerts |
| POST | `/webhooks/github` | GitHub App webhooks |

## Environment Variables

```bash
# Optional - Queen works without these but gains features with them
export PORT=3000
export GITHUB_APP_ID=1884781
export GITHUB_WEBHOOK_SECRET=your-github-secret
export ZAPIER_WEBHOOK_SECRET=your-zapier-secret
export NATS_URL=nats://localhost:4222
export DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/...
```

## Connect to Zapier

1. In your Zap, add "Webhooks by Zapier" action
2. Choose "POST" method
3. URL: `https://YOUR-CODESPACE.github.dev/signals/academic`
4. Payload Type: JSON
5. Map your email fields

## Connect to GitHub App

1. Go to GitHub App settings
2. Set Webhook URL: `https://YOUR-CODESPACE.github.dev/webhooks/github`
3. Set Webhook Secret (same as `GITHUB_WEBHOOK_SECRET`)
4. Enable events you want to receive

## Test

```bash
# Health check
curl https://YOUR-CODESPACE.github.dev/health

# Send test signal
curl -X POST https://YOUR-CODESPACE.github.dev/signals/academic \
  -H "Content-Type: application/json" \
  -d '{"Subject": "Test Email", "from": "test@snhu.edu"}'
```

## Architecture

```
Zapier ──────────────────┐
                         │
GitHub Webhooks ─────────┼──► QUEEN ──► Signal Queue ──► [Future: NATS]
                         │         │
Thread Bank ─────────────┘         └──► Logs ──► [Future: Elasticsearch]
                                   │
                                   └──► [Future: Discord Notifications]
```

## License

Proprietary - Strategickhaos DAO LLC
