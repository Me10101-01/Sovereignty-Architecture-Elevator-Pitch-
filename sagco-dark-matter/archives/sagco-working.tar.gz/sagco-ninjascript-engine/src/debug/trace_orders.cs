// trace_orders.cs — SAGCO TraceOrders wrapper
// Wraps NinjaTrader's TraceOrders system with SAGCO ERU verdict tagging.
// Every order state transition is logged with claim context.

using System;
using NinjaTrader.Cbi;

namespace Sagco.Debug
{
    public static class SagcoTraceOrders
    {
        // Called from OnOrderUpdate() in every SAGCO strategy
        public static void OnOrder(Order order, double limitPrice, double stopPrice,
                                   int quantity, string message)
        {
            string claimId = $"ORDER-{order.Name.ToUpper().Replace(" ", "-")}";
            string state   = order.OrderState.ToString().ToUpper();

            string verdict = state switch
            {
                "FILLED"    => "PROVEN",
                "CANCELLED" => "FAILED_COMPUTE",
                "REJECTED"  => "FAILED_COMPUTE",
                "WORKING"   => "UNCOMPUTED",
                _           => "COMPUTED",
            };

            SagcoPrintTrace.Print(
                "TRACE_ORDER",
                $"order={order.Name} state={state} qty={quantity} " +
                $"fill={order.AverageFillPrice:F4} limit={limitPrice:F4} stop={stopPrice:F4} msg={message}",
                verdict
            );
        }

        // Called from OnExecutionUpdate()
        public static void OnExecution(Execution execution, string claimId = "TRADE")
        {
            double ratio = execution.Price > 0 ? execution.Price / execution.Order.AverageFillPrice : 0;

            SagcoPrintTrace.ERU(
                $"EXEC-{claimId}",
                expected: execution.Order.AverageFillPrice,
                actual:   execution.Price,
                domain:   "trading"
            );

            SagcoPrintTrace.Print(
                "TRACE_EXEC",
                $"instrument={execution.Instrument.FullName} qty={execution.Quantity} " +
                $"price={execution.Price:F4} time={execution.Time:HH:mm:ss.fff}",
                SagcoPrintTrace.ClassifyRatio(ratio)
            );
        }

        // Smoke test — call once in OnStateChange → State.DataLoaded to confirm trace is active
        public static void SmokeTest(string strategyName)
        {
            SagcoPrintTrace.Print(
                "SMOKE_TEST",
                $"TraceOrders ACTIVE on strategy={strategyName} — SAGCO debug bridge COMPUTED",
                "COMPUTED"
            );
        }
    }
}
