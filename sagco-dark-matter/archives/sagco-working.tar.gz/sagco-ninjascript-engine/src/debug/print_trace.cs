// print_trace.cs — SAGCO Print() wrapper
// Routes all NinjaScript Print() calls through ERU verdict tagging.
// Never call NinjaTrader's raw Print() directly — always use SagcoPrintTrace.Print().

using System;
using System.IO;

namespace Sagco.Debug
{
    public static class SagcoPrintTrace
    {
        // Set by the strategy during OnStateChange → State.DataLoaded
        public static string LogPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            "SAGCO", "logs", "ninjascript_print.log"
        );

        public static void Print(string component, string message, string verdict = "COMPUTED")
        {
            string ts    = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
            string entry = $"[{verdict,15}] {ts}  [{component}]  {message}";

            // NinjaTrader output window
            NinjaTrader.NinjaScript.NinjaScript.Log(entry, NinjaTrader.Cbi.LogLevel.Information);

            // SAGCO flat-file log (feeds invocation_logger.py on next Python pipeline run)
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(LogPath));
                File.AppendAllText(LogPath, entry + Environment.NewLine);
            }
            catch { /* never let log IO crash the strategy */ }
        }

        public static void ERU(string claimId, double expected, double actual, string domain = "trading")
        {
            double ratio   = expected != 0 ? actual / expected : 0.0;
            string verdict = ClassifyRatio(ratio);
            Print("ERU", $"claim={claimId} expected={expected:F4} actual={actual:F4} V={ratio:F6} verdict={verdict} domain={domain}", verdict);
        }

        public static void Antibody(string abId, string trigger)
        {
            Print("ANTIBODY", $"[{abId}] FIRED — {trigger}", "FAILED_COMPUTE");
        }

        public static string ClassifyRatio(double ratio)
        {
            if (ratio >= 1.0)  return "PROVEN";
            if (ratio >= 0.5)  return "PROMISING";
            if (ratio >= 0.01) return "UNPROVEN";
            return "INFLATED";
        }
    }
}
