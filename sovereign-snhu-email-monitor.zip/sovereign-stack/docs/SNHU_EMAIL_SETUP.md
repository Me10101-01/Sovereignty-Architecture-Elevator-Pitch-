# SNHU Email Monitor Setup Guide

## Prerequisites

- Access to Azure AD (either through SNHU or personal Microsoft account)
- Kubernetes cluster running (jarvis-swarm-personal-001)
- Discord server with webhook permissions
- NATS JetStream (included in k8s manifest)

---

## Step 1: Azure AD App Registration

### Option A: If SNHU Allows App Registration

1. Go to https://portal.azure.com
2. Navigate to: Azure Active Directory → App registrations → New registration
3. Configure:
   - **Name:** `Strategickhaos SNHU Monitor`
   - **Supported account types:** Single tenant
   - **Redirect URI:** Leave blank (daemon app)
4. Click **Register**
5. Note down:
   - **Application (client) ID** → `AZURE_CLIENT_ID`
   - **Directory (tenant) ID** → `AZURE_TENANT_ID`

6. Go to: Certificates & secrets → New client secret
   - **Description:** `snhu-monitor-secret`
   - **Expires:** 24 months
   - Copy the **Value** immediately → `AZURE_CLIENT_SECRET`

7. Go to: API permissions → Add a permission → Microsoft Graph
   - Select **Application permissions**
   - Add: `Mail.Read` (Read mail in all mailboxes)
   - Click **Grant admin consent** (if you have admin rights)

### Option B: If SNHU Restricts Access (Use Delegated Flow)

If you can't register apps in SNHU's Azure AD, use OAuth2 with delegated permissions:

1. Register app in your personal Azure AD
2. Use delegated permissions instead of application permissions
3. You'll need to authenticate interactively once to get refresh token
4. Store refresh token securely

**Alternative: Use IMAP with App Password**

If Graph API is blocked:
1. Go to https://myaccount.microsoft.com/security-info
2. Enable App passwords (requires MFA enabled)
3. Generate app password for SNHU email
4. Modify service to use IMAP instead

---

## Step 2: Create Discord Webhook

1. Open Discord → Your server → Server Settings
2. Go to: Integrations → Webhooks → New Webhook
3. Configure:
   - **Name:** `SNHU Monitor`
   - **Channel:** `#snhu-academic` (or your preferred channel)
4. Copy **Webhook URL** → `DISCORD_WEBHOOK_URL`

---

## Step 3: Deploy to Kubernetes

### 3.1 Update Secrets

Edit `k8s/snhu-email-monitor.yaml` and replace placeholders:

```yaml
stringData:
  AZURE_TENANT_ID: "your-actual-tenant-id"
  AZURE_CLIENT_ID: "your-actual-client-id"
  AZURE_CLIENT_SECRET: "your-actual-client-secret"
  DISCORD_WEBHOOK_URL: "https://discord.com/api/webhooks/..."
  NATS_URL: "nats://nats.sovereign-comms.svc.cluster.local:4222"
```

### 3.2 Apply Manifests

```bash
# Connect to GKE cluster
gcloud container clusters get-credentials jarvis-swarm-personal-001 \
  --region us-central1 \
  --project jarvis-swarm-personal

# Create namespace and deploy
kubectl apply -f k8s/snhu-email-monitor.yaml

# Verify deployment
kubectl get pods -n sovereign-comms
kubectl logs -f deployment/snhu-email-monitor -n sovereign-comms
```

### 3.3 Monitor NATS

```bash
# Port-forward NATS monitor
kubectl port-forward svc/nats-monitor 8222:8222 -n sovereign-comms

# Open in browser
open http://localhost:8222
```

---

## Step 4: Test the System

### Manual Test

```bash
# Send yourself a test email with subject containing "deadline"
# Watch the logs
kubectl logs -f deployment/snhu-email-monitor -n sovereign-comms

# Check Discord channel for notification
```

### NATS Test

```bash
# Subscribe to NATS subject
nats sub "snhu.email.incoming.>" --server nats://localhost:4222
```

---

## Configuration Reference

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `AZURE_TENANT_ID` | Azure AD tenant ID | Yes |
| `AZURE_CLIENT_ID` | App registration client ID | Yes |
| `AZURE_CLIENT_SECRET` | App registration secret | Yes |
| `DISCORD_WEBHOOK_URL` | Discord webhook URL | Yes |
| `NATS_URL` | NATS server URL | Yes |
| `POLL_INTERVAL` | Seconds between checks (default: 300) | No |

### NATS Subjects

| Subject Pattern | Description |
|-----------------|-------------|
| `snhu.email.incoming.low` | Low priority emails |
| `snhu.email.incoming.medium` | Medium priority emails |
| `snhu.email.incoming.high` | High priority emails |
| `snhu.email.incoming.critical` | Critical emails (academic standing, etc.) |

### Priority Classification

| Priority | Criteria |
|----------|----------|
| CRITICAL | Keywords: "academic standing", "financial hold", "dismissal" |
| HIGH | From priority senders OR subject contains priority keywords |
| MEDIUM | Any @snhu.edu sender |
| LOW | Everything else |

---

## Troubleshooting

### "Token request failed"
- Check Azure AD app registration
- Verify API permissions are granted
- Ensure client secret hasn't expired

### "NATS connection failed"
- Verify NATS pod is running: `kubectl get pods -n sovereign-comms`
- Check NATS URL in environment

### No Discord notifications
- Verify webhook URL is correct
- Check Discord channel permissions
- Look for errors in logs

### Missing emails
- Graph API may have delays
- Check Azure AD permissions include `Mail.Read`
- Verify service principal has access to mailbox

---

## Integration with Existing Sovereign Stack

### Connect to Contradiction Detection

Add a NATS subscriber that forwards to your existing contradiction detector:

```python
# Add to your existing sovereign stack
async def on_snhu_email(msg):
    event = json.loads(msg.data)
    
    # Forward to contradiction detection
    await nc.publish("contradiction.check", json.dumps({
        "source": "snhu_email",
        "content": event["preview"],
        "metadata": event
    }))

await js.subscribe("snhu.email.incoming.>", cb=on_snhu_email)
```

### Connect to Obsidian Vault

Add handler to create notes for deadlines:

```python
async def on_deadline_email(msg):
    event = json.loads(msg.data)
    
    if "deadlines" in event["categories"]:
        # Create Obsidian note
        note = f"""
# {event["subject"]}

**From:** {event["sender"]}
**Received:** {event["received_at"]}
**Priority:** {event["priority"]}

## Preview

{event["preview"]}

---
*Auto-generated by SNHU Email Monitor*
"""
        # Write to Obsidian vault (via sync or API)
```

---

## Security Notes

1. **Never commit secrets to git**
2. **Rotate Azure AD secret annually**
3. **Use Kubernetes secrets, not ConfigMaps for credentials**
4. **Enable audit logging in Azure AD**
5. **Monitor for suspicious access patterns**

---

*Part of Strategickhaos Sovereign Stack*
*Last Updated: December 3, 2025*
