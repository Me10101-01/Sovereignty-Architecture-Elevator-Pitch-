#!/usr/bin/env python3
"""
SNHU Email Monitor Service
Part of Strategickhaos Sovereign Stack

Monitors domenic.garza@snhu.edu via Microsoft Graph API
Publishes events to NATS JetStream
Routes to Discord, GitHub, Obsidian based on content

Author: Strategickhaos DAO LLC
License: Proprietary
"""

import os
import json
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict
from enum import Enum

import aiohttp
from nats.aio.client import Client as NATS
from nats.js.api import StreamConfig, RetentionPolicy

# =============================================================================
# CONFIGURATION
# =============================================================================

@dataclass
class Config:
    # Microsoft Graph API
    tenant_id: str = os.getenv("AZURE_TENANT_ID", "")
    client_id: str = os.getenv("AZURE_CLIENT_ID", "")
    client_secret: str = os.getenv("AZURE_CLIENT_SECRET", "")
    graph_scope: str = "https://graph.microsoft.com/.default"
    graph_base_url: str = "https://graph.microsoft.com/v1.0"
    user_email: str = "domenic.garza@snhu.edu"
    
    # NATS JetStream
    nats_url: str = os.getenv("NATS_URL", "nats://localhost:4222")
    nats_stream: str = "SNHU_EMAILS"
    nats_subject: str = "snhu.email.incoming"
    
    # Discord Webhook
    discord_webhook_url: str = os.getenv("DISCORD_WEBHOOK_URL", "")
    discord_channel_name: str = "#snhu-academic"
    
    # Polling (fallback if webhooks unavailable)
    poll_interval_seconds: int = 300  # 5 minutes
    
    # Alert Configuration
    priority_senders: List[str] = None
    priority_subjects: List[str] = None
    
    def __post_init__(self):
        if self.priority_senders is None:
            self.priority_senders = [
                "registrar@snhu.edu",
                "financialservices@snhu.edu",
                "academicadvising@snhu.edu",
                "brightspace",
                "noreply@snhu.edu"
            ]
        if self.priority_subjects is None:
            self.priority_subjects = [
                "deadline",
                "capstone",
                "grade",
                "urgent",
                "action required",
                "academic standing",
                "financial aid",
                "graduation",
                "final project",
                "submission"
            ]


class Priority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class EmailEvent:
    id: str
    subject: str
    sender: str
    sender_email: str
    received_at: str
    preview: str
    has_attachments: bool
    priority: str
    categories: List[str]
    web_link: str
    
    def to_json(self) -> str:
        return json.dumps(asdict(self))


# =============================================================================
# MICROSOFT GRAPH CLIENT
# =============================================================================

class GraphClient:
    """Microsoft Graph API client for Office365 email access"""
    
    def __init__(self, config: Config):
        self.config = config
        self.access_token: Optional[str] = None
        self.token_expires: Optional[datetime] = None
        self.session: Optional[aiohttp.ClientSession] = None
        self.logger = logging.getLogger("GraphClient")
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, *args):
        if self.session:
            await self.session.close()
    
    async def get_token(self) -> str:
        """Get OAuth2 access token using client credentials flow"""
        if self.access_token and self.token_expires and datetime.utcnow() < self.token_expires:
            return self.access_token
        
        token_url = f"https://login.microsoftonline.com/{self.config.tenant_id}/oauth2/v2.0/token"
        
        data = {
            "grant_type": "client_credentials",
            "client_id": self.config.client_id,
            "client_secret": self.config.client_secret,
            "scope": self.config.graph_scope
        }
        
        async with self.session.post(token_url, data=data) as resp:
            if resp.status != 200:
                error = await resp.text()
                raise Exception(f"Token request failed: {error}")
            
            result = await resp.json()
            self.access_token = result["access_token"]
            expires_in = result.get("expires_in", 3600)
            self.token_expires = datetime.utcnow() + timedelta(seconds=expires_in - 60)
            
            self.logger.info("Obtained new access token")
            return self.access_token
    
    async def get_recent_emails(self, minutes: int = 10) -> List[Dict[str, Any]]:
        """Fetch emails received in the last N minutes"""
        token = await self.get_token()
        
        # Calculate time filter
        since = (datetime.utcnow() - timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M:%SZ")
        
        url = (
            f"{self.config.graph_base_url}/users/{self.config.user_email}/messages"
            f"?$filter=receivedDateTime ge {since}"
            f"&$select=id,subject,from,receivedDateTime,bodyPreview,hasAttachments,categories,webLink"
            f"&$orderby=receivedDateTime desc"
            f"&$top=50"
        )
        
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        async with self.session.get(url, headers=headers) as resp:
            if resp.status != 200:
                error = await resp.text()
                self.logger.error(f"Failed to fetch emails: {error}")
                return []
            
            result = await resp.json()
            return result.get("value", [])
    
    async def get_unread_emails(self) -> List[Dict[str, Any]]:
        """Fetch all unread emails"""
        token = await self.get_token()
        
        url = (
            f"{self.config.graph_base_url}/users/{self.config.user_email}/messages"
            f"?$filter=isRead eq false"
            f"&$select=id,subject,from,receivedDateTime,bodyPreview,hasAttachments,categories,webLink"
            f"&$orderby=receivedDateTime desc"
            f"&$top=100"
        )
        
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        async with self.session.get(url, headers=headers) as resp:
            if resp.status != 200:
                error = await resp.text()
                self.logger.error(f"Failed to fetch emails: {error}")
                return []
            
            result = await resp.json()
            return result.get("value", [])


# =============================================================================
# EMAIL PROCESSOR
# =============================================================================

class EmailProcessor:
    """Processes emails and determines priority/categorization"""
    
    def __init__(self, config: Config):
        self.config = config
        self.logger = logging.getLogger("EmailProcessor")
        self.seen_ids: set = set()
    
    def classify_priority(self, email: Dict[str, Any]) -> Priority:
        """Determine email priority based on sender and subject"""
        sender_email = email.get("from", {}).get("emailAddress", {}).get("address", "").lower()
        subject = email.get("subject", "").lower()
        
        # Critical: Financial or academic standing
        critical_keywords = ["academic standing", "financial hold", "dismissal", "probation"]
        if any(kw in subject for kw in critical_keywords):
            return Priority.CRITICAL
        
        # High: Priority senders or subjects
        if any(s in sender_email for s in self.config.priority_senders):
            return Priority.HIGH
        
        if any(s in subject for s in self.config.priority_subjects):
            return Priority.HIGH
        
        # Medium: Any @snhu.edu sender
        if "snhu.edu" in sender_email:
            return Priority.MEDIUM
        
        return Priority.LOW
    
    def categorize(self, email: Dict[str, Any]) -> List[str]:
        """Auto-categorize email content"""
        subject = email.get("subject", "").lower()
        preview = email.get("bodyPreview", "").lower()
        combined = f"{subject} {preview}"
        
        categories = []
        
        if any(kw in combined for kw in ["grade", "score", "feedback", "rubric"]):
            categories.append("grades")
        
        if any(kw in combined for kw in ["deadline", "due", "submit", "assignment"]):
            categories.append("deadlines")
        
        if any(kw in combined for kw in ["capstone", "final project", "milestone"]):
            categories.append("capstone")
        
        if any(kw in combined for kw in ["financial", "tuition", "payment", "aid"]):
            categories.append("financial")
        
        if any(kw in combined for kw in ["register", "enrollment", "course", "schedule"]):
            categories.append("registration")
        
        if not categories:
            categories.append("general")
        
        return categories
    
    def process(self, raw_email: Dict[str, Any]) -> Optional[EmailEvent]:
        """Convert raw Graph API email to EmailEvent"""
        email_id = raw_email.get("id")
        
        # Skip if already seen
        if email_id in self.seen_ids:
            return None
        
        self.seen_ids.add(email_id)
        
        # Keep seen_ids bounded
        if len(self.seen_ids) > 10000:
            self.seen_ids = set(list(self.seen_ids)[-5000:])
        
        from_data = raw_email.get("from", {}).get("emailAddress", {})
        
        event = EmailEvent(
            id=email_id,
            subject=raw_email.get("subject", "(No Subject)"),
            sender=from_data.get("name", "Unknown"),
            sender_email=from_data.get("address", ""),
            received_at=raw_email.get("receivedDateTime", ""),
            preview=raw_email.get("bodyPreview", "")[:500],
            has_attachments=raw_email.get("hasAttachments", False),
            priority=self.classify_priority(raw_email).value,
            categories=self.categorize(raw_email),
            web_link=raw_email.get("webLink", "")
        )
        
        return event


# =============================================================================
# NATS PUBLISHER
# =============================================================================

class NATSPublisher:
    """Publishes email events to NATS JetStream"""
    
    def __init__(self, config: Config):
        self.config = config
        self.nc: Optional[NATS] = None
        self.js = None
        self.logger = logging.getLogger("NATSPublisher")
    
    async def connect(self):
        """Connect to NATS and ensure stream exists"""
        self.nc = NATS()
        await self.nc.connect(self.config.nats_url)
        self.js = self.nc.jetstream()
        
        # Create stream if not exists
        try:
            await self.js.add_stream(
                config=StreamConfig(
                    name=self.config.nats_stream,
                    subjects=[f"{self.config.nats_subject}.*"],
                    retention=RetentionPolicy.LIMITS,
                    max_msgs=10000,
                    max_age=7 * 24 * 60 * 60 * 1_000_000_000  # 7 days in nanoseconds
                )
            )
            self.logger.info(f"Created stream: {self.config.nats_stream}")
        except Exception as e:
            if "already exists" not in str(e).lower():
                self.logger.warning(f"Stream creation note: {e}")
        
        self.logger.info(f"Connected to NATS at {self.config.nats_url}")
    
    async def publish(self, event: EmailEvent):
        """Publish email event to JetStream"""
        subject = f"{self.config.nats_subject}.{event.priority}"
        
        ack = await self.js.publish(
            subject,
            event.to_json().encode(),
            headers={"priority": event.priority}
        )
        
        self.logger.info(f"Published to {subject}: seq={ack.seq}")
    
    async def close(self):
        if self.nc:
            await self.nc.close()


# =============================================================================
# DISCORD NOTIFIER
# =============================================================================

class DiscordNotifier:
    """Sends notifications to Discord webhook"""
    
    def __init__(self, config: Config):
        self.config = config
        self.logger = logging.getLogger("DiscordNotifier")
    
    def _priority_color(self, priority: str) -> int:
        """Return Discord embed color based on priority"""
        colors = {
            "critical": 0xFF0000,  # Red
            "high": 0xFFA500,      # Orange
            "medium": 0xFFFF00,    # Yellow
            "low": 0x00FF00        # Green
        }
        return colors.get(priority, 0x808080)
    
    def _priority_emoji(self, priority: str) -> str:
        emojis = {
            "critical": "🚨",
            "high": "⚠️",
            "medium": "📧",
            "low": "📬"
        }
        return emojis.get(priority, "📩")
    
    async def notify(self, event: EmailEvent):
        """Send Discord notification for email event"""
        if not self.config.discord_webhook_url:
            self.logger.warning("No Discord webhook configured")
            return
        
        emoji = self._priority_emoji(event.priority)
        
        embed = {
            "title": f"{emoji} {event.subject[:100]}",
            "description": event.preview[:300] + ("..." if len(event.preview) > 300 else ""),
            "color": self._priority_color(event.priority),
            "fields": [
                {"name": "From", "value": f"{event.sender}\n`{event.sender_email}`", "inline": True},
                {"name": "Priority", "value": event.priority.upper(), "inline": True},
                {"name": "Categories", "value": ", ".join(event.categories), "inline": True},
            ],
            "timestamp": event.received_at,
            "footer": {"text": "SNHU Email Monitor | Strategickhaos Sovereign Stack"}
        }
        
        if event.has_attachments:
            embed["fields"].append({"name": "📎 Attachments", "value": "Yes", "inline": True})
        
        payload = {
            "username": "SNHU Monitor",
            "avatar_url": "https://www.snhu.edu/favicon.ico",
            "embeds": [embed]
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(self.config.discord_webhook_url, json=payload) as resp:
                if resp.status not in (200, 204):
                    error = await resp.text()
                    self.logger.error(f"Discord notification failed: {error}")
                else:
                    self.logger.info(f"Sent Discord notification for: {event.subject[:50]}")


# =============================================================================
# MAIN SERVICE
# =============================================================================

class SNHUEmailMonitor:
    """Main service orchestrating email monitoring"""
    
    def __init__(self, config: Config):
        self.config = config
        self.processor = EmailProcessor(config)
        self.nats_pub = NATSPublisher(config)
        self.discord = DiscordNotifier(config)
        self.logger = logging.getLogger("SNHUEmailMonitor")
        self.running = False
    
    async def start(self):
        """Start the monitoring service"""
        self.logger.info("Starting SNHU Email Monitor...")
        
        # Connect to NATS
        await self.nats_pub.connect()
        
        self.running = True
        
        async with GraphClient(self.config) as graph:
            # Initial fetch of unread emails
            self.logger.info("Fetching initial unread emails...")
            unread = await graph.get_unread_emails()
            self.logger.info(f"Found {len(unread)} unread emails")
            
            for raw_email in unread:
                event = self.processor.process(raw_email)
                if event:
                    await self._handle_event(event)
            
            # Start polling loop
            self.logger.info(f"Starting poll loop (interval: {self.config.poll_interval_seconds}s)")
            
            while self.running:
                try:
                    await asyncio.sleep(self.config.poll_interval_seconds)
                    
                    # Fetch recent emails
                    recent = await graph.get_recent_emails(minutes=10)
                    
                    for raw_email in recent:
                        event = self.processor.process(raw_email)
                        if event:
                            await self._handle_event(event)
                
                except Exception as e:
                    self.logger.error(f"Poll loop error: {e}")
                    await asyncio.sleep(60)  # Wait before retry
    
    async def _handle_event(self, event: EmailEvent):
        """Process a new email event"""
        self.logger.info(f"New email: [{event.priority}] {event.subject[:50]}")
        
        # Publish to NATS
        try:
            await self.nats_pub.publish(event)
        except Exception as e:
            self.logger.error(f"NATS publish failed: {e}")
        
        # Send Discord notification for medium+ priority
        if event.priority in ("medium", "high", "critical"):
            try:
                await self.discord.notify(event)
            except Exception as e:
                self.logger.error(f"Discord notification failed: {e}")
    
    async def stop(self):
        """Stop the monitoring service"""
        self.running = False
        await self.nats_pub.close()
        self.logger.info("SNHU Email Monitor stopped")


# =============================================================================
# ENTRY POINT
# =============================================================================

async def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s"
    )
    
    config = Config()
    
    # Validate required config
    if not all([config.tenant_id, config.client_id, config.client_secret]):
        logging.error("Missing Azure AD credentials. Set AZURE_TENANT_ID, AZURE_CLIENT_ID, AZURE_CLIENT_SECRET")
        return
    
    monitor = SNHUEmailMonitor(config)
    
    try:
        await monitor.start()
    except KeyboardInterrupt:
        logging.info("Shutting down...")
    finally:
        await monitor.stop()


if __name__ == "__main__":
    asyncio.run(main())
