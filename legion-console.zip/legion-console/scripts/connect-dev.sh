#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# CONNECT DEV
# Establish port-forwards to Legion services
# ═══════════════════════════════════════════════════════════════

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

QUIET=false
if [ "$1" == "--quiet" ] || [ "$1" == "-q" ]; then
    QUIET=true
fi

# PID file for managing port-forwards
PID_FILE="/tmp/legion-portforward.pids"

# ─────────────────────────────────────────────────────────────────
# KILL EXISTING PORT-FORWARDS
# ─────────────────────────────────────────────────────────────────
cleanup() {
    if [ -f "$PID_FILE" ]; then
        while read -r PID; do
            kill "$PID" 2>/dev/null || true
        done < "$PID_FILE"
        rm -f "$PID_FILE"
    fi
}

# Handle Ctrl+C
trap cleanup EXIT

# Kill existing
cleanup

if [ "$QUIET" == false ]; then
    echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}${CYAN}  LEGION CONNECT${NC}"
    echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
fi

# ─────────────────────────────────────────────────────────────────
# CHECK CLUSTER
# ─────────────────────────────────────────────────────────────────
if ! kubectl cluster-info &>/dev/null; then
    echo -e "${RED}Cannot connect to cluster${NC}"
    exit 1
fi

# ─────────────────────────────────────────────────────────────────
# PORT-FORWARD FUNCTION
# ─────────────────────────────────────────────────────────────────
forward_service() {
    local NS="$1"
    local SVC="$2"
    local LOCAL_PORT="$3"
    local REMOTE_PORT="$4"
    local NAME="$5"
    
    # Check if service exists
    if kubectl get svc "$SVC" -n "$NS" &>/dev/null; then
        # Check if local port is already in use
        if ! nc -z localhost "$LOCAL_PORT" 2>/dev/null; then
            kubectl port-forward "svc/$SVC" -n "$NS" "$LOCAL_PORT:$REMOTE_PORT" &>/dev/null &
            echo $! >> "$PID_FILE"
            
            # Wait a moment and verify
            sleep 1
            if nc -z localhost "$LOCAL_PORT" 2>/dev/null; then
                if [ "$QUIET" == false ]; then
                    echo -e "  ${GREEN}✓${NC} $NAME → localhost:$LOCAL_PORT"
                fi
                return 0
            fi
        else
            if [ "$QUIET" == false ]; then
                echo -e "  ${YELLOW}○${NC} $NAME (port $LOCAL_PORT already in use)"
            fi
            return 0
        fi
    else
        if [ "$QUIET" == false ]; then
            echo -e "  ${RED}✗${NC} $NAME (service not found)"
        fi
        return 1
    fi
}

# ─────────────────────────────────────────────────────────────────
# ESTABLISH FORWARDS
# ─────────────────────────────────────────────────────────────────
if [ "$QUIET" == false ]; then
    echo -e "${BOLD}Establishing port-forwards...${NC}"
    echo ""
fi

# Core data services
forward_service "legion-data" "redis-master" 6379 6379 "Redis"
forward_service "legion-data" "qdrant" 6333 6333 "Qdrant"
forward_service "legion-data" "qdrant" 6334 6334 "Qdrant gRPC"

# LLM services
forward_service "legion-llm" "ollama" 11434 11434 "Ollama"

# Optional services (won't error if not present)
forward_service "legion-obs" "grafana" 3000 3000 "Grafana" 2>/dev/null || true
forward_service "legion-obs" "prometheus" 9090 9090 "Prometheus" 2>/dev/null || true

# Dashboard if exists
forward_service "legion-core" "legion-dashboard" 8080 8080 "Dashboard" 2>/dev/null || true

if [ "$QUIET" == false ]; then
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "Services available at:"
    echo ""
    
    nc -z localhost 6379 2>/dev/null && echo "  Redis:     redis://localhost:6379"
    nc -z localhost 6333 2>/dev/null && echo "  Qdrant:    http://localhost:6333"
    nc -z localhost 11434 2>/dev/null && echo "  Ollama:    http://localhost:11434"
    nc -z localhost 3000 2>/dev/null && echo "  Grafana:   http://localhost:3000"
    nc -z localhost 8080 2>/dev/null && echo "  Dashboard: http://localhost:8080"
    
    echo ""
    echo "Port-forwards running in background."
    echo "They will terminate when this shell exits."
    echo ""
    echo "To keep running, use: nohup legion connect &"
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    
    # Keep script running to maintain port-forwards
    echo ""
    echo "Press Ctrl+C to stop port-forwards..."
    
    # Wait indefinitely (port-forwards run as background processes)
    while true; do
        sleep 60
        
        # Check if port-forwards are still alive
        ALIVE=0
        if [ -f "$PID_FILE" ]; then
            while read -r PID; do
                if kill -0 "$PID" 2>/dev/null; then
                    ALIVE=$((ALIVE + 1))
                fi
            done < "$PID_FILE"
        fi
        
        if [ "$ALIVE" -eq 0 ]; then
            echo -e "${YELLOW}All port-forwards have terminated${NC}"
            exit 0
        fi
    done
fi
