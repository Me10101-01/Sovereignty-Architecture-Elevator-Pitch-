#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# BOOTSTRAP CLUSTER
# Initialize a cluster with Legion core services
# ═══════════════════════════════════════════════════════════════

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

CLUSTER_TYPE="${1:-gke}"  # gke, k3s, kind, minikube

echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${CYAN}  LEGION CLUSTER BOOTSTRAP${NC}"
echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "Cluster type: ${YELLOW}$CLUSTER_TYPE${NC}"
echo ""

# ─────────────────────────────────────────────────────────────────
# PREREQUISITES CHECK
# ─────────────────────────────────────────────────────────────────
echo -e "${BOLD}[1/6] Checking prerequisites...${NC}"

check_cmd() {
    if command -v "$1" &>/dev/null; then
        echo -e "  ${GREEN}✓${NC} $1"
        return 0
    else
        echo -e "  ${RED}✗${NC} $1 not found"
        return 1
    fi
}

MISSING=0
check_cmd kubectl || MISSING=1
check_cmd helm || MISSING=1
check_cmd kustomize || MISSING=1

if [ "$MISSING" -eq 1 ]; then
    echo -e "${RED}Missing required tools. Install them first.${NC}"
    exit 1
fi

# ─────────────────────────────────────────────────────────────────
# CLUSTER CONNECTION
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[2/6] Verifying cluster connection...${NC}"

if ! kubectl cluster-info &>/dev/null; then
    echo -e "${RED}Cannot connect to cluster.${NC}"
    echo ""
    echo "Setup instructions by cluster type:"
    echo ""
    echo "GKE:"
    echo "  gcloud container clusters get-credentials CLUSTER_NAME --zone ZONE"
    echo ""
    echo "k3s (local):"
    echo "  export KUBECONFIG=/etc/rancher/k3s/k3s.yaml"
    echo ""
    echo "kind:"
    echo "  kind create cluster --name legion"
    echo ""
    echo "minikube:"
    echo "  minikube start"
    exit 1
fi

CTX=$(kubectl config current-context)
echo -e "  Connected to: ${GREEN}$CTX${NC}"

# ─────────────────────────────────────────────────────────────────
# CREATE NAMESPACES
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[3/6] Creating namespaces...${NC}"

NAMESPACES=(
    "legion-core"      # Core infrastructure
    "legion-agents"    # AI agents
    "legion-data"      # Databases, vector stores
    "legion-llm"       # LLM services
    "legion-obs"       # Observability
)

for NS in "${NAMESPACES[@]}"; do
    if kubectl get namespace "$NS" &>/dev/null; then
        echo -e "  ${YELLOW}○${NC} $NS (exists)"
    else
        kubectl create namespace "$NS"
        echo -e "  ${GREEN}✓${NC} $NS"
    fi
done

# ─────────────────────────────────────────────────────────────────
# INSTALL CORE SERVICES
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[4/6] Installing core services...${NC}"

# Add Helm repos
helm repo add bitnami https://charts.bitnami.com/bitnami 2>/dev/null || true
helm repo add qdrant https://qdrant.github.io/qdrant-helm 2>/dev/null || true
helm repo update

# Redis
echo -e "  Installing Redis..."
helm upgrade --install redis bitnami/redis \
    --namespace legion-data \
    --set architecture=standalone \
    --set auth.enabled=false \
    --set master.persistence.size=8Gi \
    --wait --timeout=5m 2>/dev/null || echo -e "  ${YELLOW}Redis already installed or failed${NC}"
echo -e "  ${GREEN}✓${NC} Redis"

# Qdrant
echo -e "  Installing Qdrant..."
helm upgrade --install qdrant qdrant/qdrant \
    --namespace legion-data \
    --set persistence.size=10Gi \
    --wait --timeout=5m 2>/dev/null || echo -e "  ${YELLOW}Qdrant already installed or failed${NC}"
echo -e "  ${GREEN}✓${NC} Qdrant"

# ─────────────────────────────────────────────────────────────────
# DEPLOY OLLAMA (if GPU available)
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[5/6] Deploying LLM services...${NC}"

# Check for GPU nodes
GPU_NODES=$(kubectl get nodes -o json | jq '[.items[] | select(.status.allocatable["nvidia.com/gpu"] != null)] | length')

if [ "$GPU_NODES" -gt 0 ]; then
    echo -e "  ${GREEN}✓${NC} GPU nodes detected: $GPU_NODES"
    
    # Apply Ollama with GPU
    cat <<EOF | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ollama
  namespace: legion-llm
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ollama
  template:
    metadata:
      labels:
        app: ollama
    spec:
      containers:
      - name: ollama
        image: ollama/ollama:latest
        ports:
        - containerPort: 11434
        resources:
          limits:
            nvidia.com/gpu: 1
        volumeMounts:
        - name: ollama-data
          mountPath: /root/.ollama
      volumes:
      - name: ollama-data
        persistentVolumeClaim:
          claimName: ollama-pvc
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: ollama-pvc
  namespace: legion-llm
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 50Gi
---
apiVersion: v1
kind: Service
metadata:
  name: ollama
  namespace: legion-llm
spec:
  selector:
    app: ollama
  ports:
  - port: 11434
    targetPort: 11434
EOF
    echo -e "  ${GREEN}✓${NC} Ollama (GPU)"
else
    echo -e "  ${YELLOW}○${NC} No GPU nodes - Ollama will run on CPU"
    
    # Apply Ollama CPU-only
    cat <<EOF | kubectl apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ollama
  namespace: legion-llm
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ollama
  template:
    metadata:
      labels:
        app: ollama
    spec:
      containers:
      - name: ollama
        image: ollama/ollama:latest
        ports:
        - containerPort: 11434
        resources:
          requests:
            memory: "4Gi"
            cpu: "2"
          limits:
            memory: "16Gi"
            cpu: "8"
        volumeMounts:
        - name: ollama-data
          mountPath: /root/.ollama
      volumes:
      - name: ollama-data
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: ollama
  namespace: legion-llm
spec:
  selector:
    app: ollama
  ports:
  - port: 11434
    targetPort: 11434
EOF
    echo -e "  ${GREEN}✓${NC} Ollama (CPU)"
fi

# ─────────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[6/6] Bootstrap complete!${NC}"
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo "Services deployed:"
echo "  • Redis       → legion-data/redis-master:6379"
echo "  • Qdrant      → legion-data/qdrant:6333"
echo "  • Ollama      → legion-llm/ollama:11434"
echo ""
echo "To access services locally:"
echo "  legion connect"
echo ""
echo "To check status:"
echo "  legion status"
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
