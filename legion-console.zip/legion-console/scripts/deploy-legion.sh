#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# DEPLOY LEGION
# Deploy full Legion stack to cluster
# ═══════════════════════════════════════════════════════════════

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

ENV="${1:-dev}"
MANIFESTS_DIR="${REPO_ROOT}/manifests"

echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${CYAN}  LEGION DEPLOYMENT${NC}"
echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "Environment: ${YELLOW}$ENV${NC}"
echo -e "Manifests:   ${YELLOW}$MANIFESTS_DIR${NC}"
echo ""

# ─────────────────────────────────────────────────────────────────
# VERIFY CLUSTER
# ─────────────────────────────────────────────────────────────────
echo -e "${BOLD}[1/5] Verifying cluster...${NC}"

if ! kubectl cluster-info &>/dev/null; then
    echo -e "${RED}Cannot connect to cluster${NC}"
    exit 1
fi

CTX=$(kubectl config current-context)
echo -e "  Context: ${GREEN}$CTX${NC}"

# Confirmation for prod
if [ "$ENV" == "prod" ]; then
    echo ""
    echo -e "${YELLOW}⚠ PRODUCTION DEPLOYMENT${NC}"
    read -p "Are you sure you want to deploy to PRODUCTION? (yes/no): " CONFIRM
    if [ "$CONFIRM" != "yes" ]; then
        echo "Aborted."
        exit 0
    fi
fi

# ─────────────────────────────────────────────────────────────────
# LOAD ENVIRONMENT CONFIG
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[2/5] Loading configuration...${NC}"

ENV_FILE="${REPO_ROOT}/envs/${ENV}.env"
if [ -f "$ENV_FILE" ]; then
    set -a
    source "$ENV_FILE"
    set +a
    echo -e "  ${GREEN}✓${NC} Loaded $ENV_FILE"
else
    echo -e "  ${YELLOW}○${NC} No env file at $ENV_FILE (using defaults)"
fi

# ─────────────────────────────────────────────────────────────────
# CREATE/UPDATE CONFIGMAPS & SECRETS
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[3/5] Applying configs and secrets...${NC}"

# Create configmap from env file if it exists
if [ -f "${REPO_ROOT}/.env" ]; then
    kubectl create configmap legion-config \
        --from-env-file="${REPO_ROOT}/.env" \
        --namespace=legion-core \
        --dry-run=client -o yaml | kubectl apply -f -
    echo -e "  ${GREEN}✓${NC} legion-config ConfigMap"
fi

# Apply secrets from secrets/ directory if exists
if [ -d "${REPO_ROOT}/secrets/${ENV}" ]; then
    for secret_file in "${REPO_ROOT}/secrets/${ENV}"/*.yaml; do
        if [ -f "$secret_file" ]; then
            kubectl apply -f "$secret_file"
            echo -e "  ${GREEN}✓${NC} Applied $(basename $secret_file)"
        fi
    done
fi

# ─────────────────────────────────────────────────────────────────
# DEPLOY MANIFESTS
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[4/5] Deploying manifests...${NC}"

# Check for kustomization
if [ -f "${MANIFESTS_DIR}/overlays/${ENV}/kustomization.yaml" ]; then
    echo -e "  Using kustomize overlay: ${CYAN}overlays/${ENV}${NC}"
    kubectl apply -k "${MANIFESTS_DIR}/overlays/${ENV}"
elif [ -f "${MANIFESTS_DIR}/kustomization.yaml" ]; then
    echo -e "  Using base kustomization"
    kubectl apply -k "${MANIFESTS_DIR}"
elif [ -d "${MANIFESTS_DIR}" ]; then
    echo -e "  Applying raw manifests"
    kubectl apply -f "${MANIFESTS_DIR}/" --recursive
else
    echo -e "  ${YELLOW}○${NC} No manifests directory found - creating sample structure"
    mkdir -p "${MANIFESTS_DIR}/base"
    mkdir -p "${MANIFESTS_DIR}/overlays/dev"
    mkdir -p "${MANIFESTS_DIR}/overlays/prod"
    
    # Create sample kustomization
    cat > "${MANIFESTS_DIR}/base/kustomization.yaml" <<EOF
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources: []
# Add your manifests here:
# - deployment.yaml
# - service.yaml
# - configmap.yaml
EOF
    
    cat > "${MANIFESTS_DIR}/overlays/dev/kustomization.yaml" <<EOF
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
  - ../../base

# Dev-specific patches
# patchesStrategicMerge:
#   - replica-patch.yaml
EOF
    
    echo -e "  ${GREEN}✓${NC} Created manifests structure"
fi

# ─────────────────────────────────────────────────────────────────
# WAIT FOR ROLLOUT
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[5/5] Waiting for rollout...${NC}"

# Get all deployments in legion namespaces
LEGION_NAMESPACES=$(kubectl get namespaces -o name | grep legion | cut -d/ -f2)

for NS in $LEGION_NAMESPACES; do
    DEPS=$(kubectl get deployments -n "$NS" -o name 2>/dev/null)
    for DEP in $DEPS; do
        echo -e "  Waiting for $DEP in $NS..."
        kubectl rollout status "$DEP" -n "$NS" --timeout=120s || true
    done
done

# ─────────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}DEPLOYMENT COMPLETE${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""

# Show running pods
echo -e "${BOLD}Running pods:${NC}"
for NS in $LEGION_NAMESPACES; do
    PODS=$(kubectl get pods -n "$NS" --no-headers 2>/dev/null | wc -l)
    if [ "$PODS" -gt 0 ]; then
        echo -e "\n${CYAN}$NS:${NC}"
        kubectl get pods -n "$NS" --no-headers | awk '{print "  " $1 " - " $3}'
    fi
done

echo ""
echo "Next steps:"
echo "  legion status     - Check full status"
echo "  legion connect    - Setup port-forwards"
echo "  legion logs       - Tail all logs"
echo ""
