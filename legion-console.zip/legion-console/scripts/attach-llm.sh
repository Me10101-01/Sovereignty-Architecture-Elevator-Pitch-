#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# ATTACH LLM
# Connect to Ollama/LLM services
# ═══════════════════════════════════════════════════════════════

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
PURPLE='\033[0;35m'
NC='\033[0m'
BOLD='\033[1m'

OLLAMA_HOST="${OLLAMA_HOST:-localhost}"
OLLAMA_PORT="${OLLAMA_PORT:-11434}"
OLLAMA_URL="http://${OLLAMA_HOST}:${OLLAMA_PORT}"

echo -e "${BOLD}${PURPLE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${PURPLE}  LEGION LLM ATTACH${NC}"
echo -e "${BOLD}${PURPLE}═══════════════════════════════════════════════════════════════${NC}"
echo ""

# ─────────────────────────────────────────────────────────────────
# CHECK LOCAL OLLAMA
# ─────────────────────────────────────────────────────────────────
echo -e "${BOLD}[1/4] Checking local Ollama...${NC}"

if curl -s "${OLLAMA_URL}/api/tags" &>/dev/null; then
    echo -e "  ${GREEN}✓${NC} Ollama running at ${OLLAMA_URL}"
    LOCAL_OLLAMA=true
else
    echo -e "  ${YELLOW}○${NC} No local Ollama at ${OLLAMA_URL}"
    LOCAL_OLLAMA=false
fi

# ─────────────────────────────────────────────────────────────────
# CHECK KUBERNETES OLLAMA
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[2/4] Checking Kubernetes Ollama...${NC}"

K8S_OLLAMA=false
if kubectl get pods -l app=ollama -A --no-headers 2>/dev/null | grep -q Running; then
    K8S_NS=$(kubectl get pods -l app=ollama -A --no-headers 2>/dev/null | awk '{print $1}' | head -1)
    echo -e "  ${GREEN}✓${NC} Ollama running in namespace: ${CYAN}$K8S_NS${NC}"
    K8S_OLLAMA=true
else
    echo -e "  ${YELLOW}○${NC} No Ollama pods in cluster"
fi

# ─────────────────────────────────────────────────────────────────
# ESTABLISH CONNECTION
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[3/4] Establishing connection...${NC}"

if [ "$LOCAL_OLLAMA" == true ]; then
    echo -e "  Using local Ollama"
elif [ "$K8S_OLLAMA" == true ]; then
    echo -e "  Starting port-forward to cluster Ollama..."
    
    # Kill any existing port-forward on 11434
    pkill -f "port-forward.*11434" 2>/dev/null || true
    sleep 1
    
    kubectl port-forward svc/ollama -n "$K8S_NS" 11434:11434 &>/dev/null &
    PF_PID=$!
    
    # Wait for port-forward to establish
    for i in {1..10}; do
        if curl -s "${OLLAMA_URL}/api/tags" &>/dev/null; then
            echo -e "  ${GREEN}✓${NC} Port-forward established (PID: $PF_PID)"
            break
        fi
        sleep 1
    done
    
    if ! curl -s "${OLLAMA_URL}/api/tags" &>/dev/null; then
        echo -e "  ${RED}✗${NC} Failed to establish port-forward"
        exit 1
    fi
else
    echo -e "  ${YELLOW}No Ollama available. Starting local Ollama...${NC}"
    
    # Check if ollama binary exists
    if command -v ollama &>/dev/null; then
        ollama serve &>/dev/null &
        sleep 3
        
        if curl -s "${OLLAMA_URL}/api/tags" &>/dev/null; then
            echo -e "  ${GREEN}✓${NC} Started local Ollama"
        else
            echo -e "  ${RED}✗${NC} Failed to start Ollama"
            exit 1
        fi
    else
        echo -e "  ${RED}✗${NC} Ollama not installed"
        echo ""
        echo "Install Ollama:"
        echo "  curl -fsSL https://ollama.com/install.sh | sh"
        exit 1
    fi
fi

# ─────────────────────────────────────────────────────────────────
# SHOW MODELS
# ─────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[4/4] Available models...${NC}"
echo ""

MODELS=$(curl -s "${OLLAMA_URL}/api/tags" | jq -r '.models[]? | "\(.name)\t\(.size / 1000000000 | . * 100 | floor / 100)GB\t\(.modified_at[:10])"' 2>/dev/null)

if [ -n "$MODELS" ]; then
    echo -e "${CYAN}NAME                          SIZE      MODIFIED${NC}"
    echo "$MODELS" | column -t -s $'\t'
else
    echo -e "  ${YELLOW}No models installed${NC}"
    echo ""
    echo "  Pull a model:"
    echo "    legion pull qwen2.5:7b"
    echo "    legion pull llama3.2:3b"
    echo "    legion pull mistral:7b"
fi

echo ""
echo -e "${PURPLE}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo "Ollama API: ${OLLAMA_URL}"
echo ""
echo "Quick commands:"
echo "  legion models          - List models"
echo "  legion pull <model>    - Pull a model"
echo ""
echo "Python usage:"
echo "  from ollama import Client"
echo "  client = Client(host='${OLLAMA_URL}')"
echo "  response = client.chat(model='qwen2.5:7b', messages=[...])"
echo ""
echo "curl usage:"
echo "  curl ${OLLAMA_URL}/api/generate -d '{\"model\":\"qwen2.5:7b\",\"prompt\":\"Hello\"}'"
echo ""
echo -e "${PURPLE}═══════════════════════════════════════════════════════════════${NC}"

# ─────────────────────────────────────────────────────────────────
# INTERACTIVE MODE (optional)
# ─────────────────────────────────────────────────────────────────
if [ "$1" == "--interactive" ] || [ "$1" == "-i" ]; then
    echo ""
    echo -e "${BOLD}Starting interactive session...${NC}"
    
    # Check if a model is specified
    MODEL="${2:-qwen2.5:7b}"
    
    # Check if model exists
    if ! curl -s "${OLLAMA_URL}/api/tags" | jq -e ".models[] | select(.name == \"$MODEL\")" &>/dev/null; then
        echo -e "${YELLOW}Model $MODEL not found. Pulling...${NC}"
        curl -X POST "${OLLAMA_URL}/api/pull" -d "{\"name\": \"$MODEL\"}"
    fi
    
    echo ""
    echo "Chat with $MODEL (Ctrl+C to exit)"
    echo "─────────────────────────────────"
    
    while true; do
        echo -n "You: "
        read -r INPUT
        
        if [ -z "$INPUT" ]; then
            continue
        fi
        
        echo -n "AI: "
        curl -s "${OLLAMA_URL}/api/generate" \
            -d "{\"model\": \"$MODEL\", \"prompt\": \"$INPUT\", \"stream\": false}" | \
            jq -r '.response'
        echo ""
    done
fi
