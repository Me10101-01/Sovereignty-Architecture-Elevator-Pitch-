#!/bin/bash
set -e

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║         LEGION CONSOLE - INITIALIZATION                   ║"
echo "╚═══════════════════════════════════════════════════════════╝"

# ─────────────────────────────────────────────────────────────────
# KUBECONFIG MERGE
# ─────────────────────────────────────────────────────────────────
echo "[1/5] Configuring kubectl contexts..."

mkdir -p ~/.kube

# If host kubeconfig mounted, merge it
if [ -d ~/.kube-host ] && [ -f ~/.kube-host/config ]; then
    cp ~/.kube-host/config ~/.kube/config
    chmod 600 ~/.kube/config
    echo "      ✓ Merged host kubeconfig"
fi

# Merge any contexts from repo's kubectl/ directory
if [ -d /workspaces/legion-console/kubectl/contexts ]; then
    for ctx in /workspaces/legion-console/kubectl/contexts/*.yaml; do
        if [ -f "$ctx" ]; then
            KUBECONFIG=~/.kube/config:"$ctx" kubectl config view --flatten > ~/.kube/config.tmp
            mv ~/.kube/config.tmp ~/.kube/config
            echo "      ✓ Merged $(basename $ctx)"
        fi
    done
fi

# ─────────────────────────────────────────────────────────────────
# GITHUB CLI AUTH
# ─────────────────────────────────────────────────────────────────
echo "[2/5] Configuring GitHub CLI..."

mkdir -p ~/.config/gh

# If host gh config mounted, use it
if [ -d ~/.config/gh-host ] && [ -f ~/.config/gh-host/hosts.yml ]; then
    cp ~/.config/gh-host/hosts.yml ~/.config/gh/hosts.yml
    echo "      ✓ Using host gh auth"
else
    echo "      ⚠ No gh auth found - run 'gh auth login' manually"
fi

# ─────────────────────────────────────────────────────────────────
# LEGION CLI SETUP
# ─────────────────────────────────────────────────────────────────
echo "[3/5] Installing Legion CLI..."

# Make scripts executable
chmod +x /workspaces/legion-console/scripts/*.sh 2>/dev/null || true
chmod +x /workspaces/legion-console/legion 2>/dev/null || true

# Symlink legion CLI to path
if [ -f /workspaces/legion-console/legion ]; then
    sudo ln -sf /workspaces/legion-console/legion /usr/local/bin/legion
    echo "      ✓ Legion CLI installed"
fi

# ─────────────────────────────────────────────────────────────────
# ENVIRONMENT FILE
# ─────────────────────────────────────────────────────────────────
echo "[4/5] Loading environment..."

if [ -f /workspaces/legion-console/.env ]; then
    set -a
    source /workspaces/legion-console/.env
    set +a
    echo "      ✓ Environment loaded"
else
    echo "      ⚠ No .env file - copy .env.example to .env"
fi

# ─────────────────────────────────────────────────────────────────
# VERIFY CONNECTIONS
# ─────────────────────────────────────────────────────────────────
echo "[5/5] Verifying connections..."

# Check kubectl
if kubectl cluster-info &>/dev/null; then
    CURRENT_CTX=$(kubectl config current-context)
    echo "      ✓ Kubernetes: $CURRENT_CTX"
else
    echo "      ⚠ Kubernetes: Not connected"
fi

# Check gh
if gh auth status &>/dev/null; then
    echo "      ✓ GitHub CLI: Authenticated"
else
    echo "      ⚠ GitHub CLI: Not authenticated"
fi

echo ""
echo "════════════════════════════════════════════════════════════════"
echo " Legion Console Ready"
echo " "
echo " Quick commands:"
echo "   legion status      - Show all systems status"
echo "   legion deploy      - Deploy full stack"
echo "   legion attach-llm  - Connect to Ollama/LLMs"
echo "   legion logs        - Tail all pod logs"
echo "   k9s                - Kubernetes TUI"
echo "════════════════════════════════════════════════════════════════"
