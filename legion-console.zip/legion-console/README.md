# Legion Console

**Unified command interface for Legion of Minds OS**

```
╔═══════════════════════════════════════════════════════════════╗
║     ██╗     ███████╗ ██████╗ ██╗ ██████╗ ███╗   ██╗          ║
║     ██║     ██╔════╝██╔════╝ ██║██╔═══██╗████╗  ██║          ║
║     ██║     █████╗  ██║  ███╗██║██║   ██║██╔██╗ ██║          ║
║     ██║     ██╔══╝  ██║   ██║██║██║   ██║██║╚██╗██║          ║
║     ███████╗███████╗╚██████╔╝██║╚██████╔╝██║ ╚████║          ║
║     ╚══════╝╚══════╝ ╚═════╝ ╚═╝ ╚═════╝ ╚═╝  ╚═══╝          ║
║                    Council of Minds OS                        ║
╚═══════════════════════════════════════════════════════════════╝
```

## Quick Start

### Option 1: GitHub Codespaces (Recommended)
1. Open this repo in Codespaces
2. Wait for container to build
3. Run `legion status`

### Option 2: Local Dev Container
```bash
git clone https://github.com/YOUR_ORG/legion-console.git
cd legion-console
# Open in VS Code with Dev Containers extension
code .
# F1 → "Dev Containers: Reopen in Container"
```

### Option 3: Direct CLI
```bash
git clone https://github.com/YOUR_ORG/legion-console.git
cd legion-console
chmod +x legion
./legion status
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        LEGION CONSOLE                           │
│                    (this repo = your cockpit)                   │
└───────────────────────────┬─────────────────────────────────────┘
                            │
            ┌───────────────┼───────────────┐
            ▼               ▼               ▼
    ┌───────────────┐ ┌───────────────┐ ┌───────────────┐
    │  Kubernetes   │ │    GitHub     │ │   LLM Stack   │
    │   Clusters    │ │  Enterprise   │ │   (Ollama)    │
    │               │ │               │ │               │
    │ • GKE         │ │ • Repos       │ │ • Qwen2.5     │
    │ • k3s         │ │ • Actions     │ │ • Llama       │
    │ • Homelab     │ │ • Runners     │ │ • Mistral     │
    └───────────────┘ └───────────────┘ └───────────────┘
            │               │               │
            └───────────────┼───────────────┘
                            ▼
                    ┌───────────────┐
                    │  Data Layer   │
                    │               │
                    │ • Qdrant      │
                    │ • Redis       │
                    └───────────────┘
```

---

## Directory Structure

```
legion-console/
├── .devcontainer/          # Codespaces / Dev Container config
│   ├── devcontainer.json
│   ├── Dockerfile
│   ├── post-create.sh
│   └── tmux.conf
├── scripts/                # Individual scripts
│   ├── bootstrap-cluster.sh
│   ├── deploy-legion.sh
│   ├── connect-dev.sh
│   └── attach-llm.sh
├── kubectl/                # Kubernetes configs
│   └── contexts/           # Additional kubeconfig contexts
├── manifests/              # Kubernetes manifests
│   ├── base/               # Base kustomize
│   └── overlays/           # Environment overlays
│       ├── dev/
│       └── prod/
├── envs/                   # Environment configs
│   ├── dev.env
│   └── prod.env
├── secrets/                # Secret templates (gitignored)
│   └── .gitkeep
├── legion                  # Main CLI entry point
├── .env.example            # Environment template
└── README.md
```

---

## Commands

### Core
| Command | Description |
|---------|-------------|
| `legion status` | Show all systems status |
| `legion deploy [env]` | Deploy stack (default: dev) |
| `legion destroy` | Tear down deployments |

### Cluster
| Command | Description |
|---------|-------------|
| `legion bootstrap [type]` | Bootstrap new cluster |
| `legion contexts` | List kubectl contexts |
| `legion connect` | Setup port-forwards |

### LLM
| Command | Description |
|---------|-------------|
| `legion attach-llm` | Connect to Ollama |
| `legion models` | List available models |
| `legion pull <model>` | Pull a model |

### Observability
| Command | Description |
|---------|-------------|
| `legion logs [service]` | Tail logs |
| `legion dash` | Open k9s TUI |

### Git/GitHub
| Command | Description |
|---------|-------------|
| `legion sync` | Sync all repos |
| `legion prs` | List open PRs |
| `legion runs` | Recent workflow runs |

---

## Tmux Layouts

Inside tmux, use these prefix shortcuts:

| Keys | Layout |
|------|--------|
| `Ctrl-a D` | Legion Dashboard (k9s + logs + status + shell) |
| `Ctrl-a L` | LLM Development (editor + ollama logs + redis) |
| `Ctrl-a G` | Git workflow (status + PRs + runs) |

---

## Configuration

### Add a Kubernetes Cluster

1. Copy `kubectl/contexts/EXAMPLE.yaml.template` to `kubectl/contexts/my-cluster.yaml`
2. Fill in your cluster details
3. Rebuild container or run `legion connect`

### Environment Variables

```bash
cp .env.example .env
# Edit .env with your settings
```

### Secrets

Create secret files in `secrets/dev/` or `secrets/prod/`:

```yaml
# secrets/dev/api-keys.yaml
apiVersion: v1
kind: Secret
metadata:
  name: api-keys
  namespace: legion-core
type: Opaque
stringData:
  OPENAI_API_KEY: "sk-..."
```

---

## Service Ports

When running `legion connect`:

| Service | Port | URL |
|---------|------|-----|
| Ollama | 11434 | http://localhost:11434 |
| Qdrant | 6333 | http://localhost:6333 |
| Redis | 6379 | redis://localhost:6379 |
| Grafana | 3000 | http://localhost:3000 |
| Dashboard | 8080 | http://localhost:8080 |

---

## Workflows

### Deploy to Dev
```bash
legion bootstrap      # First time only
legion deploy dev
legion connect
legion status
```

### Deploy to Prod
```bash
legion deploy prod    # Requires confirmation
```

### Add New Model
```bash
legion attach-llm
legion pull qwen2.5:14b
legion models
```

### Debug Issues
```bash
legion logs           # All logs
legion logs ollama    # Specific service
legion dash           # k9s TUI
```

---

## Integration with GitHub Enterprise

This console is designed to be the "cockpit" of your GitHub Enterprise organization.

Recommended org structure:
```
LegendsOfMinds-OS/                (Your Enterprise Org)
├── legion-console                (This repo - cockpit)
├── infra-clusters                (Terraform/cluster configs)
├── legion-agents                 (AI agents, bots, tools)
├── llm-stack                     (Ollama configs, models)
└── dev-env                       (dotfiles, shared configs)
```

Self-hosted runners in your cluster allow GitHub Actions to deploy directly:
```yaml
# .github/workflows/deploy.yaml
jobs:
  deploy:
    runs-on: self-hosted
    steps:
      - uses: actions/checkout@v4
      - run: ./legion deploy dev
```

---

## Troubleshooting

### Port already in use
```bash
pkill -f "port-forward"
legion connect
```

### Can't connect to cluster
```bash
kubectl config get-contexts
kubectl config use-context YOUR_CONTEXT
kubectl cluster-info
```

### Ollama not responding
```bash
# Check if running in cluster
kubectl get pods -l app=ollama -A

# Check local
curl http://localhost:11434/api/tags

# Restart connection
legion attach-llm
```

---

## License

MIT
